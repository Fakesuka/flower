# Font Files

This directory should contain:

- GeistVF.woff - Download from https://vercel.com/font

For development, the app will fall back to system fonts if Geist is not available.

Playfair Display is loaded from Google Fonts CDN (see globals.css).
