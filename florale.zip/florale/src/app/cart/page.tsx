'use client';

import { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import { useCartStore } from '@/store/cart';
import { useTelegram } from '@/lib/telegram';
import { formatPrice } from '@/lib/utils';
import { fadeInUp, staggerContainer, staggerItem } from '@/lib/motion';

export default function CartPage() {
  const router = useRouter();
  const { items, totalPrice, totalItems, removeItem, updateQuantity, clearCart } = useCartStore();
  const { haptic, backButton, mainButton } = useTelegram();

  useEffect(() => {
    backButton.show(() => {
      router.back();
      haptic.impact('light');
    });

    return () => {
      backButton.hide();
    };
  }, [backButton, router, haptic]);

  useEffect(() => {
    if (items.length > 0) {
      mainButton.show(`Checkout • ${formatPrice(totalPrice)}`, () => {
        haptic.notification('success');
        // Navigate to checkout (mock for now)
        alert('Checkout functionality coming soon!');
      });
    } else {
      mainButton.hide();
    }

    return () => {
      mainButton.hide();
    };
  }, [items.length, totalPrice, mainButton, haptic]);

  if (items.length === 0) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center px-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          <div className="text-6xl">🌸</div>
          <h2 className="mt-4 font-serif text-2xl font-bold">Your cart is empty</h2>
          <p className="mt-2 text-stone-600 dark:text-zinc-400">
            Start creating beautiful moments
          </p>
          <button
            onClick={() => {
              router.push('/collections');
              haptic.impact('medium');
            }}
            className="mt-8 rounded-2xl bg-black px-8 py-3 font-semibold text-white transition-transform active:scale-95 dark:bg-white dark:text-black"
          >
            Browse Collections
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white dark:bg-black">
      {/* Header */}
      <div className="safe-top sticky top-0 z-10 border-b border-stone-200 bg-white/80 px-6 py-6 backdrop-blur-xl dark:border-zinc-800 dark:bg-black/80">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-serif text-3xl font-bold">Cart</h1>
            <p className="mt-1 text-sm text-stone-600 dark:text-zinc-400">
              {totalItems} {totalItems === 1 ? 'item' : 'items'}
            </p>
          </div>
          {items.length > 0 && (
            <button
              onClick={() => {
                if (confirm('Clear all items from cart?')) {
                  clearCart();
                  haptic.notification('warning');
                }
              }}
              className="text-sm font-medium text-red-600 dark:text-red-400"
            >
              Clear All
            </button>
          )}
        </div>
      </div>

      {/* Cart Items */}
      <motion.div
        variants={staggerContainer}
        initial="hidden"
        animate="visible"
        className="px-6 py-6"
      >
        <AnimatePresence mode="popLayout">
          {items.map((item) => (
            <motion.div
              key={item.id}
              variants={staggerItem}
              layout
              exit={{ opacity: 0, x: -100 }}
              className="mb-4 overflow-hidden rounded-2xl border border-stone-200 bg-white dark:border-zinc-800 dark:bg-zinc-900"
            >
              <div className="flex gap-4 p-4">
                {/* Image */}
                <div className="relative h-24 w-24 flex-shrink-0 overflow-hidden rounded-xl bg-stone-100 dark:bg-zinc-800">
                  <Image
                    src={item.image}
                    alt={item.name}
                    fill
                    className="object-cover"
                  />
                </div>

                {/* Details */}
                <div className="flex flex-1 flex-col">
                  <div className="flex-1">
                    <h3 className="font-semibold leading-tight">{item.name}</h3>
                    <p className="mt-1 text-sm text-stone-600 dark:text-zinc-400">
                      {formatPrice(item.price)}
                    </p>
                  </div>

                  {/* Quantity Controls */}
                  <div className="mt-3 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => {
                          updateQuantity(item.id, item.quantity - 1);
                          haptic.selection();
                        }}
                        className="flex h-8 w-8 items-center justify-center rounded-full border border-stone-300 text-sm font-semibold dark:border-zinc-700"
                      >
                        −
                      </button>
                      <span className="w-8 text-center font-medium">{item.quantity}</span>
                      <button
                        onClick={() => {
                          updateQuantity(item.id, item.quantity + 1);
                          haptic.selection();
                        }}
                        className="flex h-8 w-8 items-center justify-center rounded-full border border-stone-300 text-sm font-semibold dark:border-zinc-700"
                      >
                        +
                      </button>
                    </div>

                    <button
                      onClick={() => {
                        removeItem(item.id);
                        haptic.impact('light');
                      }}
                      className="text-sm font-medium text-red-600 dark:text-red-400"
                    >
                      Remove
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </motion.div>

      {/* Summary */}
      <div className="px-6 pb-32">
        <div className="rounded-2xl bg-stone-50 p-6 dark:bg-zinc-900">
          <h3 className="font-semibold">Order Summary</h3>
          <div className="mt-4 space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-stone-600 dark:text-zinc-400">Subtotal</span>
              <span className="font-medium">{formatPrice(totalPrice)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-stone-600 dark:text-zinc-400">Delivery</span>
              <span className="font-medium">
                {totalPrice >= 5000 ? 'Free' : formatPrice(300)}
              </span>
            </div>
            <div className="border-t border-stone-200 pt-3 dark:border-zinc-800">
              <div className="flex justify-between">
                <span className="font-semibold">Total</span>
                <span className="font-semibold">
                  {formatPrice(totalPrice >= 5000 ? totalPrice : totalPrice + 300)}
                </span>
              </div>
            </div>
          </div>
        </div>

        {totalPrice < 5000 && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-4 rounded-xl bg-blue-50 p-4 text-sm text-blue-800 dark:bg-blue-950 dark:text-blue-200"
          >
            Add {formatPrice(5000 - totalPrice)} more for free delivery!
          </motion.div>
        )}
      </div>
    </div>
  );
}
