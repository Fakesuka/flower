'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Timeline } from '@/components/Timeline';
import { useTelegram } from '@/lib/telegram';
import type { OrderStatus } from '@/types';

// Mock order data
const mockOrder: OrderStatus = {
  id: 'FL-2024-0234',
  status: 'on-the-way',
  estimatedDelivery: '2024-02-03T18:00:00',
  address: 'Pushkin St., 12, Apt. 45, Moscow',
  courierName: 'Ivan Petrov',
  courierPhone: '+7 (999) 123-45-67',
  timeline: {
    preparing: new Date('2024-02-03T12:00:00'),
    courierAssigned: new Date('2024-02-03T14:30:00'),
    onTheWay: new Date('2024-02-03T15:45:00'),
    delivered: null,
  },
};

export default function TrackOrderPage({ params }: { params: { orderId: string } }) {
  const router = useRouter();
  const { backButton, haptic } = useTelegram();

  useEffect(() => {
    backButton.show(() => {
      router.back();
      haptic.impact('light');
    });

    return () => {
      backButton.hide();
    };
  }, [backButton, router, haptic]);

  return (
    <div className="min-h-screen bg-white dark:bg-black">
      {/* Header */}
      <div className="safe-top sticky top-0 z-10 border-b border-stone-200 bg-white/80 px-6 py-6 backdrop-blur-xl dark:border-zinc-800 dark:bg-black/80">
        <h1 className="font-serif text-3xl font-bold">Track Order</h1>
      </div>

      {/* Timeline */}
      <div className="px-6 py-8">
        <Timeline order={mockOrder} />
      </div>
    </div>
  );
}
