'use client';

import { BuilderStepper } from '@/components/BuilderStepper';

export default function BuilderPage() {
  return <BuilderStepper />;
}
