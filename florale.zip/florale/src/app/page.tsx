'use client';

import { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import Link from 'next/link';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { StoryCarousel } from '@/components/StoryCarousel';
import { ProductCard } from '@/components/ProductCard';
import { getFeaturedProducts } from '@/data/products';
import { useTelegram } from '@/lib/telegram';
import { fadeInUp, staggerContainer, staggerItem } from '@/lib/motion';

if (typeof window !== 'undefined') {
  gsap.registerPlugin(ScrollTrigger);
}

export default function HomePage() {
  const { haptic } = useTelegram();
  const heroRef = useRef<HTMLDivElement>(null);
  const featuredProducts = getFeaturedProducts();

  useEffect(() => {
    if (!heroRef.current) return;

    const ctx = gsap.context(() => {
      // Hero title animation
      gsap.from('.hero-title', {
        y: 100,
        opacity: 0,
        duration: 1.2,
        ease: 'power3.out',
      });

      // Subtitle
      gsap.from('.hero-subtitle', {
        y: 50,
        opacity: 0,
        duration: 1,
        delay: 0.3,
        ease: 'power3.out',
      });

      // CTA Button
      gsap.from('.hero-cta', {
        y: 30,
        opacity: 0,
        duration: 0.8,
        delay: 0.6,
        ease: 'power3.out',
      });

      // Floating elements
      gsap.to('.float-1', {
        y: -20,
        duration: 2,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut',
      });

      gsap.to('.float-2', {
        y: -30,
        duration: 2.5,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut',
        delay: 0.5,
      });
    }, heroRef);

    return () => ctx.revert();
  }, []);

  return (
    <div className="min-h-screen bg-white dark:bg-black">
      {/* Hero Section */}
      <section
        ref={heroRef}
        className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden px-6 grain"
      >
        {/* Decorative Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="float-1 absolute left-10 top-20 h-32 w-32 rounded-full bg-gradient-to-br from-rose-200/30 to-pink-200/30 blur-3xl" />
          <div className="float-2 absolute bottom-20 right-10 h-40 w-40 rounded-full bg-gradient-to-br from-purple-200/30 to-blue-200/30 blur-3xl" />
        </div>

        {/* Content */}
        <div className="relative z-10 text-center">
          <h1 className="hero-title font-serif text-6xl font-bold leading-tight tracking-tight text-black dark:text-white md:text-7xl lg:text-8xl">
            Florale
          </h1>
          
          <p className="hero-subtitle mt-6 text-xl text-stone-600 dark:text-zinc-400 md:text-2xl">
            Where artistry meets nature
          </p>

          <div className="hero-cta mt-12 flex flex-col gap-4 sm:flex-row sm:justify-center">
            <Link href="/builder" onClick={() => haptic.impact('medium')}>
              <button className="w-full rounded-2xl bg-black px-8 py-4 font-semibold text-white transition-transform active:scale-95 dark:bg-white dark:text-black sm:w-auto">
                Create Your Bouquet
              </button>
            </Link>
            
            <Link href="/collections" onClick={() => haptic.impact('light')}>
              <button className="w-full rounded-2xl border-2 border-black px-8 py-4 font-semibold transition-transform active:scale-95 dark:border-white sm:w-auto">
                Explore Collections
              </button>
            </Link>
          </div>
        </div>

        {/* Scroll Indicator */}
        <motion.div
          className="absolute bottom-8 flex flex-col items-center gap-2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
        >
          <span className="text-sm text-stone-600 dark:text-zinc-400">Scroll to explore</span>
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ repeat: Infinity, duration: 1.5 }}
          >
            <svg
              className="h-6 w-6 text-stone-600 dark:text-zinc-400"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
          </motion.div>
        </motion.div>
      </section>

      {/* Story Collections */}
      <section className="relative h-screen">
        <StoryCarousel />
      </section>

      {/* Featured Products */}
      <section className="px-6 py-16 safe-bottom">
        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-100px' }}
        >
          <motion.div variants={staggerItem} className="mb-12 text-center">
            <h2 className="font-serif text-4xl font-bold md:text-5xl">
              Featured Arrangements
            </h2>
            <p className="mt-4 text-lg text-stone-600 dark:text-zinc-400">
              Handpicked selections for every occasion
            </p>
          </motion.div>

          <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
            {featuredProducts.map((product, index) => (
              <motion.div key={product.id} variants={staggerItem}>
                <ProductCard product={product} priority={index < 4} />
              </motion.div>
            ))}
          </div>

          <motion.div variants={staggerItem} className="mt-12 text-center">
            <Link href="/collections" onClick={() => haptic.impact('light')}>
              <button className="rounded-2xl border-2 border-black px-8 py-3 font-semibold transition-transform active:scale-95 dark:border-white">
                View All Products
              </button>
            </Link>
          </motion.div>
        </motion.div>
      </section>

      {/* About Section */}
      <section className="px-6 py-16">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mx-auto max-w-3xl text-center"
        >
          <h2 className="font-serif text-4xl font-bold">
            Crafted with Passion
          </h2>
          <p className="mt-6 text-lg leading-relaxed text-stone-600 dark:text-zinc-400">
            Every arrangement at Florale is a unique work of art. We source the finest blooms
            from sustainable farms and work with nature's seasonal beauty to create moments
            that last forever.
          </p>
          <div className="mt-12 grid grid-cols-3 gap-8">
            <div>
              <div className="text-3xl font-bold">500+</div>
              <div className="mt-2 text-sm text-stone-600 dark:text-zinc-400">Happy Clients</div>
            </div>
            <div>
              <div className="text-3xl font-bold">100%</div>
              <div className="mt-2 text-sm text-stone-600 dark:text-zinc-400">Fresh Blooms</div>
            </div>
            <div>
              <div className="text-3xl font-bold">24/7</div>
              <div className="mt-2 text-sm text-stone-600 dark:text-zinc-400">Support</div>
            </div>
          </div>
        </motion.div>
      </section>

      {/* CTA Footer */}
      <section className="border-t border-stone-200 px-6 py-16 dark:border-zinc-800">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mx-auto max-w-2xl text-center"
        >
          <h2 className="font-serif text-3xl font-bold md:text-4xl">
            Ready to Create Something Beautiful?
          </h2>
          <p className="mt-4 text-lg text-stone-600 dark:text-zinc-400">
            Start building your perfect bouquet with our interactive designer
          </p>
          <Link href="/builder" onClick={() => haptic.impact('medium')}>
            <button className="mt-8 rounded-2xl bg-black px-12 py-4 font-semibold text-white transition-transform active:scale-95 dark:bg-white dark:text-black">
              Launch Builder
            </button>
          </Link>
        </motion.div>
      </section>
    </div>
  );
}
