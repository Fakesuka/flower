'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import { getProductById } from '@/data/products';
import { useCartStore } from '@/store/cart';
import { useTelegram } from '@/lib/telegram';
import { formatPrice } from '@/lib/utils';
import { sharedTransition } from '@/lib/motion';

export default function ProductPage({ params }: { params: { id: string } }) {
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const router = useRouter();
  const { haptic, backButton, mainButton } = useTelegram();
  const addProduct = useCartStore((s) => s.addProduct);

  const product = getProductById(params.id);

  useEffect(() => {
    backButton.show(() => {
      router.back();
      haptic.impact('light');
    });

    return () => {
      backButton.hide();
    };
  }, [backButton, router, haptic]);

  useEffect(() => {
    if (!product) return;

    mainButton.show('Add to Cart', () => {
      addProduct(product, quantity);
      haptic.notification('success');
      router.push('/cart');
    });

    return () => {
      mainButton.hide();
    };
  }, [product, quantity, mainButton, addProduct, router, haptic]);

  if (!product) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p className="text-lg">Product not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white dark:bg-black">
      {/* Image Gallery */}
      <div className="safe-top relative aspect-[3/4] w-full overflow-hidden bg-stone-100 dark:bg-zinc-900">
        <motion.div
          layoutId={`product-image-${product.id}`}
          transition={sharedTransition}
          className="relative h-full w-full"
        >
          <Image
            src={product.images[selectedImage]}
            alt={product.name}
            fill
            className="object-cover"
            priority
          />
        </motion.div>

        {/* Image Thumbnails */}
        {product.images.length > 1 && (
          <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2 px-4">
            {product.images.map((_, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setSelectedImage(idx);
                  haptic.selection();
                }}
                className={`h-2 rounded-full transition-all ${
                  idx === selectedImage ? 'w-8 bg-white' : 'w-2 bg-white/50'
                }`}
              />
            ))}
          </div>
        )}
      </div>

      {/* Product Details */}
      <div className="px-6 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          {/* Title & Price */}
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <motion.h1
                layoutId={`product-title-${product.id}`}
                transition={sharedTransition}
                className="font-serif text-3xl font-bold leading-tight"
              >
                {product.name}
              </motion.h1>
              <p className="mt-2 text-lg text-stone-600 dark:text-zinc-400">
                {product.subtitle}
              </p>
            </div>
            <motion.div
              layoutId={`product-price-${product.id}`}
              transition={sharedTransition}
              className="font-serif text-2xl font-bold"
            >
              {formatPrice(product.price)}
            </motion.div>
          </div>

          {/* Tags */}
          <div className="mt-4 flex flex-wrap gap-2">
            {product.tags.map((tag) => (
              <span
                key={tag}
                className="rounded-full bg-stone-100 px-3 py-1 text-sm text-stone-700 dark:bg-zinc-800 dark:text-zinc-300"
              >
                {tag}
              </span>
            ))}
          </div>

          {/* Description */}
          <div className="mt-8">
            <h2 className="font-semibold">About This Arrangement</h2>
            <p className="mt-3 leading-relaxed text-stone-600 dark:text-zinc-400">
              {product.description}
            </p>
          </div>

          {/* Quantity Selector */}
          <div className="mt-8">
            <h2 className="font-semibold">Quantity</h2>
            <div className="mt-3 flex items-center gap-4">
              <button
                onClick={() => {
                  if (quantity > 1) {
                    setQuantity(quantity - 1);
                    haptic.selection();
                  }
                }}
                className="flex h-12 w-12 items-center justify-center rounded-full border-2 border-stone-200 font-semibold transition-colors hover:border-stone-300 dark:border-zinc-800"
              >
                −
              </button>
              <span className="text-xl font-semibold">{quantity}</span>
              <button
                onClick={() => {
                  setQuantity(quantity + 1);
                  haptic.selection();
                }}
                className="flex h-12 w-12 items-center justify-center rounded-full border-2 border-stone-200 font-semibold transition-colors hover:border-stone-300 dark:border-zinc-800"
              >
                +
              </button>
            </div>
          </div>

          {/* Care Instructions */}
          <div className="mt-8 rounded-2xl bg-stone-50 p-6 dark:bg-zinc-900">
            <h2 className="font-semibold">Care Instructions</h2>
            <ul className="mt-3 space-y-2 text-sm text-stone-600 dark:text-zinc-400">
              <li>• Trim stems at 45° angle before placing in water</li>
              <li>• Change water every 2-3 days</li>
              <li>• Keep away from direct sunlight and heat</li>
              <li>• Remove wilted blooms to extend freshness</li>
            </ul>
          </div>

          {/* Delivery Info */}
          <div className="mt-6 rounded-2xl bg-stone-50 p-6 dark:bg-zinc-900">
            <h2 className="font-semibold">Delivery</h2>
            <p className="mt-2 text-sm text-stone-600 dark:text-zinc-400">
              Same-day delivery available for orders placed before 2 PM.
              Free delivery on orders over {formatPrice(5000)}.
            </p>
          </div>

          {/* Stock Status */}
          {!product.inStock && (
            <div className="mt-6 rounded-2xl border-2 border-red-200 bg-red-50 p-4 dark:border-red-900 dark:bg-red-950">
              <p className="font-medium text-red-800 dark:text-red-200">
                Currently out of stock
              </p>
              <p className="mt-1 text-sm text-red-600 dark:text-red-400">
                Notify me when available
              </p>
            </div>
          )}
        </motion.div>
      </div>

      {/* Bottom Spacing for MainButton */}
      <div className="h-24" />
    </div>
  );
}
