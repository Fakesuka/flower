'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { ProductCard } from '@/components/ProductCard';
import { products } from '@/data/products';
import { collections } from '@/data/collections';
import { staggerContainer, staggerItem } from '@/lib/motion';
import { useTelegram } from '@/lib/telegram';

export default function CollectionsPage() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const { haptic } = useTelegram();

  const filteredProducts = selectedCategory
    ? products.filter((p) => p.category === selectedCategory)
    : products;

  const categories = ['all', 'classic', 'modern', 'minimal', 'wild', 'luxury'];

  return (
    <div className="min-h-screen bg-white dark:bg-black">
      {/* Header */}
      <div className="safe-top sticky top-0 z-10 border-b border-stone-200 bg-white/80 px-6 py-6 backdrop-blur-xl dark:border-zinc-800 dark:bg-black/80">
        <h1 className="font-serif text-3xl font-bold">Collections</h1>
        
        {/* Category Filter */}
        <div className="mt-4 flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => {
                setSelectedCategory(cat === 'all' ? null : cat);
                haptic.selection();
              }}
              className={`whitespace-nowrap rounded-full px-4 py-2 text-sm font-medium transition-colors ${
                (cat === 'all' && !selectedCategory) || selectedCategory === cat
                  ? 'bg-black text-white dark:bg-white dark:text-black'
                  : 'bg-stone-100 text-stone-700 dark:bg-zinc-800 dark:text-zinc-300'
              }`}
            >
              {cat.charAt(0).toUpperCase() + cat.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Collections Grid */}
      <motion.div
        variants={staggerContainer}
        initial="hidden"
        animate="visible"
        className="px-6 py-8"
      >
        {collections.length > 0 && !selectedCategory && (
          <motion.section variants={staggerItem} className="mb-12">
            <h2 className="mb-6 font-serif text-2xl font-bold">Curated Collections</h2>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {collections.map((collection) => (
                <motion.div
                  key={collection.id}
                  variants={staggerItem}
                  whileTap={{ scale: 0.98 }}
                  className="group relative aspect-[4/5] overflow-hidden rounded-2xl"
                >
                  <div className={`absolute inset-0 bg-gradient-to-br ${collection.gradient} opacity-80`} />
                  <div className="absolute inset-0 flex flex-col justify-end p-6 text-white">
                    <h3 className="font-serif text-3xl font-bold">{collection.name}</h3>
                    <p className="mt-2 text-sm opacity-90">{collection.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.section>
        )}

        {/* Products Grid */}
        <motion.section variants={staggerItem}>
          <h2 className="mb-6 font-serif text-2xl font-bold">
            {selectedCategory
              ? `${selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)} Arrangements`
              : 'All Products'}
          </h2>
          <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
            {filteredProducts.map((product) => (
              <motion.div key={product.id} variants={staggerItem}>
                <ProductCard product={product} />
              </motion.div>
            ))}
          </div>
        </motion.section>
      </motion.div>
    </div>
  );
}
