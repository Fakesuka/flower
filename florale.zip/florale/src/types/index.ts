export interface Product {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  price: number;
  images: string[];
  category: string;
  tags: string[];
  inStock: boolean;
  featured: boolean;
}

export interface Collection {
  id: string;
  name: string;
  description: string;
  image: string;
  gradient: string;
  products: string[]; // product IDs
}

export type BouquetStyle = 'classic' | 'modern' | 'minimal' | 'wild' | 'luxury';
export type ColorPalette = 'pastel' | 'bold' | 'monochrome' | 'rainbow' | 'earth';
export type BouquetSize = 'petite' | 'standard' | 'grand' | 'statement';
export type PackagingType = 'craft' | 'luxury-box' | 'silk-wrap' | 'none';

export interface BouquetConfig {
  style: BouquetStyle | null;
  palette: ColorPalette | null;
  size: BouquetSize | null;
  packaging: PackagingType | null;
  message: string;
  basePrice: number;
  addOns: {
    packaging: number;
    size: number;
  };
  totalPrice: number;
}

export interface CartItem {
  id: string;
  productId?: string;
  bouquetConfig?: BouquetConfig;
  quantity: number;
  price: number;
  name: string;
  image: string;
}

export interface OrderStatus {
  id: string;
  status: 'preparing' | 'courier-assigned' | 'on-the-way' | 'delivered';
  estimatedDelivery: string;
  address: string;
  courierName?: string;
  courierPhone?: string;
  timeline: {
    preparing: Date | null;
    courierAssigned: Date | null;
    onTheWay: Date | null;
    delivered: Date | null;
  };
}

export interface TelegramTheme {
  bgColor: string;
  textColor: string;
  hintColor: string;
  linkColor: string;
  buttonColor: string;
  buttonTextColor: string;
  secondaryBgColor: string;
  headerBgColor: string;
  accentTextColor: string;
  sectionBgColor: string;
  sectionHeaderTextColor: string;
  subtitleTextColor: string;
  destructiveTextColor: string;
}
