'use client';

import { motion } from 'framer-motion';
import Image from 'next/image';
import Link from 'next/link';
import type { Product } from '@/types';
import { formatPrice } from '@/lib/utils';
import { fadeInUp } from '@/lib/motion';
import { useTelegram } from '@/lib/telegram';

interface ProductCardProps {
  product: Product;
  priority?: boolean;
}

export function ProductCard({ product, priority = false }: ProductCardProps) {
  const { haptic } = useTelegram();

  const handleTap = () => {
    haptic.selection();
  };

  return (
    <Link href={`/product/${product.id}`} onClick={handleTap}>
      <motion.article
        variants={fadeInUp}
        whileTap={{ scale: 0.98 }}
        className="group relative overflow-hidden rounded-2xl bg-white dark:bg-zinc-900"
      >
        {/* Image Container */}
        <div className="relative aspect-[3/4] overflow-hidden bg-stone-100 dark:bg-zinc-800">
          <motion.div
            layoutId={`product-image-${product.id}`}
            className="relative h-full w-full"
          >
            <Image
              src={product.images[0]}
              alt={product.name}
              fill
              sizes="(max-width: 768px) 50vw, 33vw"
              className="object-cover transition-transform duration-700 group-hover:scale-105"
              priority={priority}
            />
          </motion.div>

          {/* Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/0 to-black/0 opacity-0 transition-opacity duration-300 group-hover:opacity-100" />

          {/* Featured Badge */}
          {product.featured && (
            <div className="absolute right-3 top-3">
              <div className="glass rounded-full px-3 py-1 text-xs font-medium text-white backdrop-blur-md">
                Featured
              </div>
            </div>
          )}

          {/* Quick Add - appears on hover */}
          <div className="absolute bottom-4 left-4 right-4 translate-y-4 opacity-0 transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100">
            <button
              className="w-full rounded-xl bg-white/90 py-3 text-sm font-semibold text-black backdrop-blur-md transition-colors hover:bg-white dark:bg-zinc-800/90 dark:text-white dark:hover:bg-zinc-800"
              onClick={(e) => {
                e.preventDefault();
                haptic.impact('medium');
              }}
            >
              Quick Add
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-4">
          <motion.h3
            layoutId={`product-title-${product.id}`}
            className="font-serif text-xl font-semibold leading-tight text-gray-900 dark:text-white"
          >
            {product.name}
          </motion.h3>
          
          <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
            {product.subtitle}
          </p>

          <div className="mt-3 flex items-center justify-between">
            <motion.span
              layoutId={`product-price-${product.id}`}
              className="text-lg font-semibold text-gray-900 dark:text-white"
            >
              {formatPrice(product.price)}
            </motion.span>

            {!product.inStock && (
              <span className="text-xs text-red-500">Out of Stock</span>
            )}
          </div>

          {/* Tags */}
          {product.tags.length > 0 && (
            <div className="mt-3 flex flex-wrap gap-1.5">
              {product.tags.slice(0, 2).map((tag) => (
                <span
                  key={tag}
                  className="rounded-full bg-stone-100 px-2 py-0.5 text-xs text-stone-600 dark:bg-zinc-800 dark:text-zinc-400"
                >
                  {tag}
                </span>
              ))}
            </div>
          )}
        </div>
      </motion.article>
    </Link>
  );
}
