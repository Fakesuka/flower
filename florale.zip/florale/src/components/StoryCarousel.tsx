'use client';

import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence, PanInfo } from 'framer-motion';
import Image from 'next/image';
import Link from 'next/link';
import { collections } from '@/data/collections';
import { useTelegram } from '@/lib/telegram';

export function StoryCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0);
  const { haptic } = useTelegram();
  const containerRef = useRef<HTMLDivElement>(null);

  const current = collections[currentIndex];

  const handleDragEnd = (_: any, info: PanInfo) => {
    const threshold = 50;
    const velocity = info.velocity.y;

    if (Math.abs(info.offset.y) > threshold || Math.abs(velocity) > 500) {
      if (info.offset.y > 0) {
        // Swipe down - previous
        paginate(-1);
      } else {
        // Swipe up - next
        paginate(1);
      }
    }
  };

  const paginate = (newDirection: number) => {
    const newIndex = currentIndex + newDirection;
    
    if (newIndex >= 0 && newIndex < collections.length) {
      setDirection(newDirection);
      setCurrentIndex(newIndex);
      haptic.selection();
    }
  };

  const variants = {
    enter: (direction: number) => ({
      y: direction > 0 ? '100%' : '-100%',
      opacity: 0,
    }),
    center: {
      y: 0,
      opacity: 1,
    },
    exit: (direction: number) => ({
      y: direction > 0 ? '-100%' : '100%',
      opacity: 0,
    }),
  };

  return (
    <div className="relative h-screen w-full overflow-hidden bg-black" ref={containerRef}>
      <AnimatePresence initial={false} custom={direction} mode="wait">
        <motion.div
          key={currentIndex}
          custom={direction}
          variants={variants}
          initial="enter"
          animate="center"
          exit="exit"
          transition={{
            y: { type: 'spring', stiffness: 300, damping: 30 },
            opacity: { duration: 0.2 },
          }}
          drag="y"
          dragConstraints={{ top: 0, bottom: 0 }}
          dragElastic={0.2}
          onDragEnd={handleDragEnd}
          className="absolute inset-0"
        >
          {/* Background Image */}
          <div className="absolute inset-0">
            <Image
              src={current.image}
              alt={current.name}
              fill
              className="object-cover"
              priority={currentIndex === 0}
            />
            {/* Gradient Overlay */}
            <div className={`absolute inset-0 bg-gradient-to-b ${current.gradient} opacity-60 mix-blend-multiply`} />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/30" />
          </div>

          {/* Content */}
          <div className="relative flex h-full flex-col justify-between p-6 safe-top safe-bottom">
            {/* Top: Progress Indicators */}
            <div className="flex gap-1">
              {collections.map((_, idx) => (
                <div
                  key={idx}
                  className="h-0.5 flex-1 overflow-hidden rounded-full bg-white/30"
                >
                  <motion.div
                    className="h-full bg-white"
                    initial={{ width: idx < currentIndex ? '100%' : '0%' }}
                    animate={{ width: idx === currentIndex ? '100%' : idx < currentIndex ? '100%' : '0%' }}
                    transition={{ duration: idx === currentIndex ? 5 : 0 }}
                  />
                </div>
              ))}
            </div>

            {/* Bottom: Collection Info */}
            <div className="space-y-6">
              <div className="space-y-2">
                <motion.h2
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="font-serif text-5xl font-bold leading-tight text-white"
                >
                  {current.name}
                </motion.h2>
                <motion.p
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="text-lg text-white/90"
                >
                  {current.description}
                </motion.p>
              </div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
              >
                <Link
                  href={`/collections?id=${current.id}`}
                  onClick={() => haptic.impact('medium')}
                >
                  <button className="w-full rounded-2xl bg-white py-4 font-semibold text-black transition-transform active:scale-95">
                    Explore Collection
                  </button>
                </Link>
              </motion.div>

              {/* Navigation Hint */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="flex items-center justify-center gap-2 text-sm text-white/70"
              >
                <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
                </svg>
                <span>Swipe to explore</span>
              </motion.div>
            </div>
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Side Indicators */}
      <div className="absolute right-4 top-1/2 -translate-y-1/2 space-y-2">
        {collections.map((_, idx) => (
          <button
            key={idx}
            onClick={() => {
              if (idx !== currentIndex) {
                setDirection(idx > currentIndex ? 1 : -1);
                setCurrentIndex(idx);
                haptic.selection();
              }
            }}
            className={`block h-2 w-2 rounded-full transition-all ${
              idx === currentIndex
                ? 'bg-white scale-125'
                : 'bg-white/40 hover:bg-white/60'
            }`}
            aria-label={`Go to ${collections[idx].name}`}
          />
        ))}
      </div>
    </div>
  );
}
