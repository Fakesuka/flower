'use client';

import { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useBuilderStore } from '@/store/builder';
import { useTelegram } from '@/lib/telegram';
import { formatPrice, cn } from '@/lib/utils';
import type { BouquetStyle, ColorPalette, BouquetSize, PackagingType } from '@/types';

const STEPS = [
  'Choose Style',
  'Select Palette',
  'Pick Size',
  'Add Packaging',
  'Personal Message',
  'Review',
];

const STYLES: { value: BouquetStyle; label: string; desc: string }[] = [
  { value: 'classic', label: 'Classic', desc: 'Timeless elegance' },
  { value: 'modern', label: 'Modern', desc: 'Contemporary design' },
  { value: 'minimal', label: 'Minimal', desc: 'Less is more' },
  { value: 'wild', label: 'Wild', desc: 'Natural & free' },
  { value: 'luxury', label: 'Luxury', desc: 'Ultimate opulence' },
];

const PALETTES: { value: ColorPalette; label: string; colors: string[] }[] = [
  { value: 'pastel', label: 'Pastel Dreams', colors: ['#FFE5E5', '#FFF0E5', '#FFFFE5', '#E5FFE5'] },
  { value: 'bold', label: 'Bold & Vibrant', colors: ['#FF4444', '#FF8800', '#FFDD00', '#FF0088'] },
  { value: 'monochrome', label: 'Monochrome', colors: ['#FFFFFF', '#E5E5E5', '#CCCCCC', '#999999'] },
  { value: 'rainbow', label: 'Rainbow Joy', colors: ['#FF0000', '#FFAA00', '#00FF00', '#0000FF'] },
  { value: 'earth', label: 'Earth Tones', colors: ['#8B4513', '#A0826D', '#C9B8A0', '#E8D5C4'] },
];

const SIZES: { value: BouquetSize; label: string; desc: string; price: number }[] = [
  { value: 'petite', label: 'Petite', desc: '15-20 stems', price: 0 },
  { value: 'standard', label: 'Standard', desc: '25-35 stems', price: 800 },
  { value: 'grand', label: 'Grand', desc: '40-50 stems', price: 1500 },
  { value: 'statement', label: 'Statement', desc: '60+ stems', price: 3000 },
];

const PACKAGING: { value: PackagingType; label: string; desc: string; price: number }[] = [
  { value: 'none', label: 'No Packaging', desc: 'Natural wrap only', price: 0 },
  { value: 'craft', label: 'Craft Paper', desc: 'Rustic elegance', price: 200 },
  { value: 'silk-wrap', label: 'Silk Wrap', desc: 'Premium fabric', price: 500 },
  { value: 'luxury-box', label: 'Luxury Box', desc: 'Gift-ready presentation', price: 800 },
];

export function BuilderStepper() {
  const { config, currentStep, setStyle, setPalette, setSize, setPackaging, setMessage, nextStep, prevStep, isStepValid } = useBuilderStore();
  const { haptic, mainButton, backButton } = useTelegram();

  useEffect(() => {
    if (currentStep > 0) {
      backButton.show(() => {
        prevStep();
        haptic.impact('light');
      });
    } else {
      backButton.hide();
    }

    return () => {
      backButton.hide();
    };
  }, [currentStep, prevStep, backButton, haptic]);

  const handleNext = () => {
    if (isStepValid(currentStep)) {
      nextStep();
      haptic.impact('medium');
    }
  };

  const canProceed = isStepValid(currentStep);

  return (
    <div className="flex h-screen flex-col bg-white dark:bg-black">
      {/* Progress Header */}
      <div className="safe-top border-b border-stone-200 bg-white px-6 py-4 dark:border-zinc-800 dark:bg-black">
        <div className="mb-3 flex items-center justify-between">
          <span className="text-sm font-medium text-stone-600 dark:text-zinc-400">
            Step {currentStep + 1} of {STEPS.length}
          </span>
          <span className="font-semibold">{formatPrice(config.totalPrice)}</span>
        </div>
        
        {/* Progress Bar */}
        <div className="relative h-1 overflow-hidden rounded-full bg-stone-100 dark:bg-zinc-900">
          <motion.div
            className="absolute left-0 top-0 h-full bg-black dark:bg-white"
            initial={{ width: 0 }}
            animate={{ width: `${((currentStep + 1) / STEPS.length) * 100}%` }}
            transition={{ duration: 0.3 }}
          />
        </div>

        <h2 className="mt-4 font-serif text-2xl font-bold">{STEPS[currentStep]}</h2>
      </div>

      {/* Step Content */}
      <div className="flex-1 overflow-y-auto px-6 py-6">
        <AnimatePresence mode="wait">
          {currentStep === 0 && <StyleStep selected={config.style} onSelect={setStyle} key="style" />}
          {currentStep === 1 && <PaletteStep selected={config.palette} onSelect={setPalette} key="palette" />}
          {currentStep === 2 && <SizeStep selected={config.size} onSelect={setSize} key="size" />}
          {currentStep === 3 && <PackagingStep selected={config.packaging} onSelect={setPackaging} key="packaging" />}
          {currentStep === 4 && <MessageStep value={config.message} onChange={setMessage} key="message" />}
          {currentStep === 5 && <ReviewStep config={config} key="review" />}
        </AnimatePresence>
      </div>

      {/* Continue Button */}
      <div className="safe-bottom border-t border-stone-200 bg-white p-6 dark:border-zinc-800 dark:bg-black">
        <button
          onClick={handleNext}
          disabled={!canProceed}
          className={cn(
            'w-full rounded-2xl py-4 font-semibold text-white transition-all',
            canProceed
              ? 'bg-black active:scale-95 dark:bg-white dark:text-black'
              : 'cursor-not-allowed bg-stone-300 dark:bg-zinc-700'
          )}
        >
          {currentStep === STEPS.length - 1 ? 'Add to Cart' : 'Continue'}
        </button>
      </div>
    </div>
  );
}

// Step Components

function StyleStep({ selected, onSelect }: { selected: BouquetStyle | null; onSelect: (s: BouquetStyle) => void }) {
  const { haptic } = useTelegram();

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="space-y-3"
    >
      {STYLES.map((style) => (
        <button
          key={style.value}
          onClick={() => {
            onSelect(style.value);
            haptic.selection();
          }}
          className={cn(
            'w-full rounded-2xl border-2 p-5 text-left transition-all',
            selected === style.value
              ? 'border-black bg-black text-white dark:border-white dark:bg-white dark:text-black'
              : 'border-stone-200 bg-white hover:border-stone-300 dark:border-zinc-800 dark:bg-zinc-900'
          )}
        >
          <div className="font-semibold">{style.label}</div>
          <div className="mt-1 text-sm opacity-70">{style.desc}</div>
        </button>
      ))}
    </motion.div>
  );
}

function PaletteStep({ selected, onSelect }: { selected: ColorPalette | null; onSelect: (p: ColorPalette) => void }) {
  const { haptic } = useTelegram();

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="space-y-3"
    >
      {PALETTES.map((palette) => (
        <button
          key={palette.value}
          onClick={() => {
            onSelect(palette.value);
            haptic.selection();
          }}
          className={cn(
            'w-full rounded-2xl border-2 p-5 text-left transition-all',
            selected === palette.value
              ? 'border-black dark:border-white'
              : 'border-stone-200 hover:border-stone-300 dark:border-zinc-800'
          )}
        >
          <div className="font-semibold">{palette.label}</div>
          <div className="mt-3 flex gap-2">
            {palette.colors.map((color, idx) => (
              <div
                key={idx}
                className="h-8 w-8 rounded-full border border-stone-200 dark:border-zinc-700"
                style={{ backgroundColor: color }}
              />
            ))}
          </div>
        </button>
      ))}
    </motion.div>
  );
}

function SizeStep({ selected, onSelect }: { selected: BouquetSize | null; onSelect: (s: BouquetSize) => void }) {
  const { haptic } = useTelegram();

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="space-y-3"
    >
      {SIZES.map((size) => (
        <button
          key={size.value}
          onClick={() => {
            onSelect(size.value);
            haptic.selection();
          }}
          className={cn(
            'w-full rounded-2xl border-2 p-5 text-left transition-all',
            selected === size.value
              ? 'border-black bg-black text-white dark:border-white dark:bg-white dark:text-black'
              : 'border-stone-200 bg-white hover:border-stone-300 dark:border-zinc-800 dark:bg-zinc-900'
          )}
        >
          <div className="flex items-center justify-between">
            <div>
              <div className="font-semibold">{size.label}</div>
              <div className="mt-1 text-sm opacity-70">{size.desc}</div>
            </div>
            {size.price > 0 && (
              <div className="text-sm font-medium">+{formatPrice(size.price)}</div>
            )}
          </div>
        </button>
      ))}
    </motion.div>
  );
}

function PackagingStep({ selected, onSelect }: { selected: PackagingType | null; onSelect: (p: PackagingType) => void }) {
  const { haptic } = useTelegram();

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="space-y-3"
    >
      {PACKAGING.map((pkg) => (
        <button
          key={pkg.value}
          onClick={() => {
            onSelect(pkg.value);
            haptic.selection();
          }}
          className={cn(
            'w-full rounded-2xl border-2 p-5 text-left transition-all',
            selected === pkg.value
              ? 'border-black bg-black text-white dark:border-white dark:bg-white dark:text-black'
              : 'border-stone-200 bg-white hover:border-stone-300 dark:border-zinc-800 dark:bg-zinc-900'
          )}
        >
          <div className="flex items-center justify-between">
            <div>
              <div className="font-semibold">{pkg.label}</div>
              <div className="mt-1 text-sm opacity-70">{pkg.desc}</div>
            </div>
            {pkg.price > 0 && (
              <div className="text-sm font-medium">+{formatPrice(pkg.price)}</div>
            )}
          </div>
        </button>
      ))}
    </motion.div>
  );
}

function MessageStep({ value, onChange }: { value: string; onChange: (m: string) => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
    >
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Add a personal message (optional)"
        maxLength={200}
        className="h-40 w-full rounded-2xl border-2 border-stone-200 p-4 focus:border-black dark:border-zinc-800 dark:bg-zinc-900 dark:focus:border-white"
      />
      <div className="mt-2 text-right text-sm text-stone-500">
        {value.length}/200
      </div>
    </motion.div>
  );
}

function ReviewStep({ config }: { config: any }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="space-y-4"
    >
      <div className="rounded-2xl bg-stone-50 p-6 dark:bg-zinc-900">
        <h3 className="font-semibold">Your Bouquet</h3>
        <div className="mt-4 space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-stone-600 dark:text-zinc-400">Style</span>
            <span className="font-medium capitalize">{config.style}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-stone-600 dark:text-zinc-400">Palette</span>
            <span className="font-medium capitalize">{config.palette}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-stone-600 dark:text-zinc-400">Size</span>
            <span className="font-medium capitalize">{config.size}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-stone-600 dark:text-zinc-400">Packaging</span>
            <span className="font-medium capitalize">{config.packaging}</span>
          </div>
        </div>
      </div>

      {config.message && (
        <div className="rounded-2xl bg-stone-50 p-6 dark:bg-zinc-900">
          <h3 className="font-semibold">Message</h3>
          <p className="mt-2 text-sm text-stone-600 dark:text-zinc-400">{config.message}</p>
        </div>
      )}
    </motion.div>
  );
}
