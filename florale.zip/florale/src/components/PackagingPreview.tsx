'use client';

import { motion } from 'framer-motion';
import type { PackagingType } from '@/types';
import { cn } from '@/lib/utils';

interface PackagingPreviewProps {
  type: PackagingType;
  className?: string;
}

const PACKAGING_STYLES = {
  none: {
    label: 'Natural Wrap',
    overlay: null,
    ribbon: false,
  },
  craft: {
    label: 'Craft Paper',
    overlay: 'repeating-linear-gradient(45deg, #d4a574 0px, #d4a574 2px, #c9975e 2px, #c9975e 4px)',
    ribbon: true,
  },
  'silk-wrap': {
    label: 'Silk Wrap',
    overlay: 'linear-gradient(135deg, rgba(255,255,255,0.3) 0%, rgba(255,255,255,0.1) 100%)',
    ribbon: true,
  },
  'luxury-box': {
    label: 'Luxury Box',
    overlay: 'linear-gradient(to bottom, #1a1a1a 0%, #2a2a2a 100%)',
    ribbon: true,
  },
};

export function PackagingPreview({ type, className }: PackagingPreviewProps) {
  const style = PACKAGING_STYLES[type];

  return (
    <div className={cn('relative overflow-hidden rounded-2xl', className)}>
      {/* Base Image/Content */}
      <div className="aspect-square w-full bg-stone-100 dark:bg-zinc-900">
        {/* Preview content would go here */}
      </div>

      {/* Packaging Overlay */}
      {style.overlay && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.6 }}
          transition={{ duration: 0.5 }}
          className="absolute inset-0 mix-blend-multiply dark:mix-blend-screen"
          style={{ background: style.overlay }}
        />
      )}

      {/* Ribbon */}
      {style.ribbon && (
        <motion.div
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ delay: 0.3, duration: 0.5 }}
          className="absolute left-0 right-0 top-1/2 h-12 -translate-y-1/2"
        >
          <div className="relative h-full w-full bg-gradient-to-r from-red-600 via-red-500 to-red-600 shadow-lg">
            {/* Ribbon shine */}
            <div className="absolute inset-0 bg-gradient-to-b from-white/30 to-transparent" />
          </div>
          
          {/* Bow */}
          <motion.div
            initial={{ scale: 0, rotate: 0 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ delay: 0.6, type: 'spring', stiffness: 200 }}
            className="absolute left-1/2 top-1/2 h-16 w-16 -translate-x-1/2 -translate-y-1/2"
          >
            <div className="absolute inset-0 rounded-full bg-gradient-to-br from-red-500 to-red-700 shadow-xl" />
            <div className="absolute inset-2 rounded-full border-2 border-white/30" />
          </motion.div>
        </motion.div>
      )}

      {/* Label */}
      <div className="absolute bottom-4 left-4 right-4">
        <div className="glass rounded-xl px-4 py-2 text-center backdrop-blur-md">
          <span className="text-sm font-medium text-white">
            {style.label}
          </span>
        </div>
      </div>
    </div>
  );
}
