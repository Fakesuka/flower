'use client';

import { motion } from 'framer-motion';
import type { OrderStatus } from '@/types';
import { formatDate, cn } from '@/lib/utils';

interface TimelineProps {
  order: OrderStatus;
}

const STATUSES = [
  { key: 'preparing' as const, label: 'Preparing', icon: '🌸' },
  { key: 'courier-assigned' as const, label: 'Courier Assigned', icon: '🚗' },
  { key: 'on-the-way' as const, label: 'On the Way', icon: '📦' },
  { key: 'delivered' as const, label: 'Delivered', icon: '✨' },
];

export function Timeline({ order }: TimelineProps) {
  const currentStatusIndex = STATUSES.findIndex((s) => s.key === order.status);

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="rounded-2xl bg-gradient-to-br from-stone-50 to-stone-100 p-6 dark:from-zinc-900 dark:to-zinc-800">
        <div className="text-sm font-medium text-stone-600 dark:text-zinc-400">Order #{order.id}</div>
        <div className="mt-2 font-serif text-2xl font-bold">
          {STATUSES[currentStatusIndex].label}
        </div>
        {order.estimatedDelivery && (
          <div className="mt-2 text-sm text-stone-600 dark:text-zinc-400">
            Estimated delivery: {formatDate(order.estimatedDelivery)}
          </div>
        )}
      </div>

      {/* Timeline */}
      <div className="relative">
        {/* Vertical Line */}
        <div className="absolute left-6 top-0 h-full w-0.5 bg-stone-200 dark:bg-zinc-800" />

        {/* Progress Line */}
        <motion.div
          className="absolute left-6 top-0 w-0.5 bg-black dark:bg-white"
          initial={{ height: 0 }}
          animate={{ height: `${(currentStatusIndex / (STATUSES.length - 1)) * 100}%` }}
          transition={{ duration: 1, ease: 'easeOut' }}
        />

        {/* Status Items */}
        <div className="space-y-8">
          {STATUSES.map((status, index) => {
            const isCompleted = index <= currentStatusIndex;
            const isCurrent = index === currentStatusIndex;
            const timestamp = order.timeline[status.key];

            return (
              <motion.div
                key={status.key}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="relative flex items-start gap-4"
              >
                {/* Icon Circle */}
                <div className="relative z-10">
                  <motion.div
                    className={cn(
                      'flex h-12 w-12 items-center justify-center rounded-full text-2xl transition-colors',
                      isCompleted
                        ? 'bg-black text-white dark:bg-white dark:text-black'
                        : 'bg-stone-200 text-stone-400 dark:bg-zinc-800 dark:text-zinc-600'
                    )}
                    animate={isCurrent ? { scale: [1, 1.1, 1] } : {}}
                    transition={{ repeat: isCurrent ? Infinity : 0, duration: 2 }}
                  >
                    {status.icon}
                  </motion.div>

                  {/* Pulse Ring for Current */}
                  {isCurrent && (
                    <motion.div
                      className="absolute inset-0 rounded-full bg-black dark:bg-white"
                      initial={{ opacity: 0.5, scale: 1 }}
                      animate={{ opacity: 0, scale: 1.5 }}
                      transition={{ repeat: Infinity, duration: 2 }}
                    />
                  )}
                </div>

                {/* Content */}
                <div className="flex-1 pb-8">
                  <div
                    className={cn(
                      'font-semibold',
                      isCompleted
                        ? 'text-black dark:text-white'
                        : 'text-stone-400 dark:text-zinc-600'
                    )}
                  >
                    {status.label}
                  </div>
                  {timestamp && (
                    <div className="mt-1 text-sm text-stone-600 dark:text-zinc-400">
                      {formatDate(timestamp)}
                    </div>
                  )}

                  {/* Additional Info */}
                  {isCurrent && status.key === 'courier-assigned' && order.courierName && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="mt-3 rounded-xl bg-stone-50 p-4 dark:bg-zinc-900"
                    >
                      <div className="text-sm font-medium">Courier Details</div>
                      <div className="mt-2 text-sm text-stone-600 dark:text-zinc-400">
                        {order.courierName}
                      </div>
                      {order.courierPhone && (
                        <a
                          href={`tel:${order.courierPhone}`}
                          className="mt-2 inline-flex items-center gap-2 text-sm font-medium text-blue-600 dark:text-blue-400"
                        >
                          <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                          </svg>
                          Call Courier
                        </a>
                      )}
                    </motion.div>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Delivery Address */}
      <div className="rounded-2xl bg-stone-50 p-6 dark:bg-zinc-900">
        <div className="text-sm font-medium text-stone-600 dark:text-zinc-400">
          Delivery Address
        </div>
        <div className="mt-2">{order.address}</div>
      </div>

      {/* Help Button */}
      <button className="w-full rounded-2xl border-2 border-stone-200 py-4 font-semibold transition-colors hover:border-stone-300 dark:border-zinc-800 dark:hover:border-zinc-700">
        Need Help? Contact Support
      </button>
    </div>
  );
}
