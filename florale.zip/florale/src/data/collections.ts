import type { Collection } from '@/types';

export const collections: Collection[] = [
  {
    id: 'c1',
    name: '8 March',
    description: 'Celebrate the women in your life with our exclusive Spring collection',
    image: 'https://images.unsplash.com/photo-1490750967868-88aa4486c946?w=800&h=1200&fit=crop',
    gradient: 'from-rose-400 via-pink-400 to-fuchsia-500',
    products: ['p1', 'p6', 'p8'],
  },
  {
    id: 'c2',
    name: 'Weddings',
    description: 'Timeless elegance for your special day',
    image: 'https://images.unsplash.com/photo-1455659817273-f96807779a8a?w=800&h=1200&fit=crop',
    gradient: 'from-white via-stone-100 to-stone-200',
    products: ['p2', 'p9', 'p10'],
  },
  {
    id: 'c3',
    name: 'Minimal',
    description: 'Less is more. Clean, sophisticated, timeless.',
    image: 'https://images.unsplash.com/photo-1525310072745-f49212b5ac6d?w=800&h=1200&fit=crop',
    gradient: 'from-slate-100 via-stone-50 to-zinc-100',
    products: ['p2', 'p10', 'p7'],
  },
  {
    id: 'c4',
    name: 'Birthday',
    description: 'Make their day unforgettable with vibrant blooms',
    image: 'https://images.unsplash.com/photo-1478909533481-8a9237e6c462?w=800&h=1200&fit=crop',
    gradient: 'from-amber-300 via-orange-400 to-rose-400',
    products: ['p4', 'p6', 'p3'],
  },
  {
    id: 'c5',
    name: 'Just Because',
    description: 'The best moments are unplanned. Surprise someone today.',
    image: 'https://images.unsplash.com/photo-1487070183336-b863922373d4?w=800&h=1200&fit=crop',
    gradient: 'from-emerald-300 via-teal-400 to-cyan-500',
    products: ['p3', 'p1', 'p8', 'p6'],
  },
  {
    id: 'c6',
    name: 'Dark Romance',
    description: 'For those who dare to be different',
    image: 'https://images.unsplash.com/photo-1606041011872-596597976ed4?w=800&h=1200&fit=crop',
    gradient: 'from-purple-900 via-rose-900 to-black',
    products: ['p5', 'p9'],
  },
];

export const getCollectionById = (id: string): Collection | undefined => {
  return collections.find((c) => c.id === id);
};
