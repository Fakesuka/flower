import type { Product } from '@/types';

export const products: Product[] = [
  {
    id: 'p1',
    name: 'Éclat Rose',
    subtitle: 'Garden Roses & Peonies',
    description: 'A delicate composition of garden roses and seasonal peonies, hand-tied with silk ribbon. Each bloom is selected at peak freshness from our partners in Provence.',
    price: 8900,
    images: [
      'https://images.unsplash.com/photo-1563241527-3004b7be0ffd?w=800&h=1000&fit=crop',
      'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&h=1000&fit=crop',
    ],
    category: 'classic',
    tags: ['romantic', 'premium', 'roses'],
    inStock: true,
    featured: true,
  },
  {
    id: 'p2',
    name: 'Nuit Blanche',
    subtitle: 'Monochrome Elegance',
    description: 'Pure white blooms create a striking minimalist statement. Featuring ranunculus, anemones, and delicate jasmine vines.',
    price: 12500,
    images: [
      'https://images.unsplash.com/photo-1490750967868-88aa4486c946?w=800&h=1000&fit=crop',
      'https://images.unsplash.com/photo-1455659817273-f96807779a8a?w=800&h=1000&fit=crop',
    ],
    category: 'minimal',
    tags: ['minimalist', 'white', 'premium'],
    inStock: true,
    featured: true,
  },
  {
    id: 'p3',
    name: 'Jardin Sauvage',
    subtitle: 'Wild Garden Mix',
    description: 'An untamed arrangement celebrating the beauty of wild meadow flowers. Seasonal blooms gathered in a natural, organic style.',
    price: 6800,
    images: [
      'https://images.unsplash.com/photo-1487070183336-b863922373d4?w=800&h=1000&fit=crop',
      'https://images.unsplash.com/photo-1535295972055-1c762f4483e5?w=800&h=1000&fit=crop',
    ],
    category: 'wild',
    tags: ['rustic', 'colorful', 'seasonal'],
    inStock: true,
    featured: false,
  },
  {
    id: 'p4',
    name: 'Lumière d\'Or',
    subtitle: 'Golden Hour Collection',
    description: 'Warm tones of amber, peach, and gold. This arrangement captures the magic of sunset with carefully selected premium blooms.',
    price: 11200,
    images: [
      'https://images.unsplash.com/photo-1561181286-d3fee7d55364?w=800&h=1000&fit=crop',
      'https://images.unsplash.com/photo-1525310072745-f49212b5ac6d?w=800&h=1000&fit=crop',
    ],
    category: 'modern',
    tags: ['warm', 'modern', 'premium'],
    inStock: true,
    featured: true,
  },
  {
    id: 'p5',
    name: 'Velours Noir',
    subtitle: 'Dark Romance',
    description: 'Deep burgundy roses, black calla lilies, and dark foliage create a dramatic, sophisticated arrangement.',
    price: 15800,
    images: [
      'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&h=1000&fit=crop',
      'https://images.unsplash.com/photo-1606041011872-596597976ed4?w=800&h=1000&fit=crop',
    ],
    category: 'luxury',
    tags: ['dramatic', 'luxury', 'dark'],
    inStock: true,
    featured: true,
  },
  {
    id: 'p6',
    name: 'Ciel Pastel',
    subtitle: 'Soft Dreams',
    description: 'Delicate pastel blooms in lavender, blush, and soft yellow. Perfect for tender moments and gentle celebrations.',
    price: 7500,
    images: [
      'https://images.unsplash.com/photo-1478909533481-8a9237e6c462?w=800&h=1000&fit=crop',
      'https://images.unsplash.com/photo-1502576830722-d1d8cfd7c0db?w=800&h=1000&fit=crop',
    ],
    category: 'classic',
    tags: ['pastel', 'soft', 'romantic'],
    inStock: true,
    featured: false,
  },
  {
    id: 'p7',
    name: 'Architecture Florale',
    subtitle: 'Structural Beauty',
    description: 'Bold geometric arrangement featuring proteas, anthuriums, and architectural greenery. A modern statement piece.',
    price: 14200,
    images: [
      'https://images.unsplash.com/photo-1563241527-3004b7be0ffd?w=800&h=1000&fit=crop',
      'https://images.unsplash.com/photo-1487070183336-b863922373d4?w=800&h=1000&fit=crop',
    ],
    category: 'modern',
    tags: ['modern', 'architectural', 'bold'],
    inStock: true,
    featured: false,
  },
  {
    id: 'p8',
    name: 'Printemps Éternel',
    subtitle: 'Spring Awakening',
    description: 'Celebrate renewal with tulips, hyacinths, and cherry blossoms. A fresh, optimistic arrangement.',
    price: 8200,
    images: [
      'https://images.unsplash.com/photo-1490750967868-88aa4486c946?w=800&h=1000&fit=crop',
      'https://images.unsplash.com/photo-1478909533481-8a9237e6c462?w=800&h=1000&fit=crop',
    ],
    category: 'classic',
    tags: ['spring', 'fresh', 'seasonal'],
    inStock: true,
    featured: false,
  },
  {
    id: 'p9',
    name: 'Opulence Royale',
    subtitle: 'Grand Luxury Arrangement',
    description: 'Our most lavish creation featuring premium peonies, garden roses, orchids, and gilded accents. A statement of ultimate luxury.',
    price: 24500,
    images: [
      'https://images.unsplash.com/photo-1561181286-d3fee7d55364?w=800&h=1000&fit=crop',
      'https://images.unsplash.com/photo-1606041011872-596597976ed4?w=800&h=1000&fit=crop',
    ],
    category: 'luxury',
    tags: ['luxury', 'grand', 'premium', 'opulent'],
    inStock: true,
    featured: true,
  },
  {
    id: 'p10',
    name: 'Zen Garden',
    subtitle: 'Minimalist Harmony',
    description: 'Clean lines and serene beauty. White orchids, lotus pods, and minimalist greenery in perfect balance.',
    price: 10800,
    images: [
      'https://images.unsplash.com/photo-1455659817273-f96807779a8a?w=800&h=1000&fit=crop',
      'https://images.unsplash.com/photo-1525310072745-f49212b5ac6d?w=800&h=1000&fit=crop',
    ],
    category: 'minimal',
    tags: ['minimalist', 'zen', 'modern'],
    inStock: true,
    featured: false,
  },
];

export const getProductById = (id: string): Product | undefined => {
  return products.find((p) => p.id === id);
};

export const getFeaturedProducts = (): Product[] => {
  return products.filter((p) => p.featured);
};

export const getProductsByCategory = (category: string): Product[] => {
  return products.filter((p) => p.category === category);
};
