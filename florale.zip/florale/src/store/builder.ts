import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { BouquetConfig, BouquetStyle, ColorPalette, BouquetSize, PackagingType } from '@/types';

interface BuilderState {
  config: BouquetConfig;
  currentStep: number;
  setStyle: (style: BouquetStyle) => void;
  setPalette: (palette: ColorPalette) => void;
  setSize: (size: BouquetSize) => void;
  setPackaging: (packaging: PackagingType) => void;
  setMessage: (message: string) => void;
  nextStep: () => void;
  prevStep: () => void;
  goToStep: (step: number) => void;
  reset: () => void;
  isStepValid: (step: number) => boolean;
}

const BASE_PRICES = {
  style: {
    classic: 0,
    modern: 500,
    minimal: 300,
    wild: 400,
    luxury: 1000,
  },
  palette: {
    pastel: 0,
    bold: 200,
    monochrome: 100,
    rainbow: 300,
    earth: 150,
  },
  size: {
    petite: 0,
    standard: 800,
    grand: 1500,
    statement: 3000,
  },
  packaging: {
    none: 0,
    craft: 200,
    'silk-wrap': 500,
    'luxury-box': 800,
  },
};

const calculatePrice = (config: BouquetConfig): number => {
  let basePrice = 2000; // Starting price

  if (config.style) basePrice += BASE_PRICES.style[config.style];
  if (config.palette) basePrice += BASE_PRICES.palette[config.palette];
  if (config.size) basePrice += BASE_PRICES.size[config.size];

  const packagingCost = config.packaging ? BASE_PRICES.packaging[config.packaging] : 0;

  return basePrice + packagingCost;
};

const initialConfig: BouquetConfig = {
  style: null,
  palette: null,
  size: null,
  packaging: null,
  message: '',
  basePrice: 2000,
  addOns: {
    packaging: 0,
    size: 0,
  },
  totalPrice: 2000,
};

export const useBuilderStore = create<BuilderState>()(
  persist(
    (set, get) => ({
      config: initialConfig,
      currentStep: 0,

      setStyle: (style) => {
        set((state) => {
          const newConfig = { ...state.config, style };
          return {
            config: {
              ...newConfig,
              totalPrice: calculatePrice(newConfig),
            },
          };
        });
      },

      setPalette: (palette) => {
        set((state) => {
          const newConfig = { ...state.config, palette };
          return {
            config: {
              ...newConfig,
              totalPrice: calculatePrice(newConfig),
            },
          };
        });
      },

      setSize: (size) => {
        set((state) => {
          const newConfig = { ...state.config, size };
          const sizeCost = BASE_PRICES.size[size];
          return {
            config: {
              ...newConfig,
              addOns: { ...state.config.addOns, size: sizeCost },
              totalPrice: calculatePrice(newConfig),
            },
          };
        });
      },

      setPackaging: (packaging) => {
        set((state) => {
          const newConfig = { ...state.config, packaging };
          const packagingCost = BASE_PRICES.packaging[packaging];
          return {
            config: {
              ...newConfig,
              addOns: { ...state.config.addOns, packaging: packagingCost },
              totalPrice: calculatePrice(newConfig),
            },
          };
        });
      },

      setMessage: (message) => {
        set((state) => ({
          config: { ...state.config, message },
        }));
      },

      nextStep: () => {
        set((state) => ({
          currentStep: Math.min(state.currentStep + 1, 5),
        }));
      },

      prevStep: () => {
        set((state) => ({
          currentStep: Math.max(state.currentStep - 1, 0),
        }));
      },

      goToStep: (step) => {
        set({ currentStep: Math.max(0, Math.min(step, 5)) });
      },

      reset: () => {
        set({
          config: initialConfig,
          currentStep: 0,
        });
      },

      isStepValid: (step) => {
        const { config } = get();
        switch (step) {
          case 0:
            return config.style !== null;
          case 1:
            return config.palette !== null;
          case 2:
            return config.size !== null;
          case 3:
            return config.packaging !== null;
          case 4:
            return true; // Message is optional
          case 5:
            return config.style !== null && 
                   config.palette !== null && 
                   config.size !== null && 
                   config.packaging !== null;
          default:
            return false;
        }
      },
    }),
    {
      name: 'florale-builder',
    }
  )
);
