import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { CartItem, Product, BouquetConfig } from '@/types';
import { generateId } from '@/lib/utils';

interface CartState {
  items: CartItem[];
  addProduct: (product: Product, quantity?: number) => void;
  addBouquet: (config: BouquetConfig, name: string, image: string) => void;
  removeItem: (id: string) => void;
  updateQuantity: (id: string, quantity: number) => void;
  clearCart: () => void;
  totalItems: number;
  totalPrice: number;
}

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],

      addProduct: (product, quantity = 1) => {
        set((state) => {
          const existing = state.items.find((item) => item.productId === product.id);
          
          if (existing) {
            return {
              items: state.items.map((item) =>
                item.productId === product.id
                  ? { ...item, quantity: item.quantity + quantity }
                  : item
              ),
            };
          }

          const newItem: CartItem = {
            id: generateId(),
            productId: product.id,
            quantity,
            price: product.price,
            name: product.name,
            image: product.images[0],
          };

          return { items: [...state.items, newItem] };
        });
      },

      addBouquet: (config, name, image) => {
        const newItem: CartItem = {
          id: generateId(),
          bouquetConfig: config,
          quantity: 1,
          price: config.totalPrice,
          name,
          image,
        };

        set((state) => ({
          items: [...state.items, newItem],
        }));
      },

      removeItem: (id) => {
        set((state) => ({
          items: state.items.filter((item) => item.id !== id),
        }));
      },

      updateQuantity: (id, quantity) => {
        if (quantity <= 0) {
          get().removeItem(id);
          return;
        }

        set((state) => ({
          items: state.items.map((item) =>
            item.id === id ? { ...item, quantity } : item
          ),
        }));
      },

      clearCart: () => {
        set({ items: [] });
      },

      get totalItems() {
        return get().items.reduce((sum, item) => sum + item.quantity, 0);
      },

      get totalPrice() {
        return get().items.reduce((sum, item) => sum + item.price * item.quantity, 0);
      },
    }),
    {
      name: 'florale-cart',
    }
  )
);
