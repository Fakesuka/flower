import { Variants } from 'framer-motion';

// Animation durations (in seconds)
export const duration = {
  fast: 0.15,
  normal: 0.3,
  slow: 0.5,
  slower: 0.8,
} as const;

// Easing curves
export const ease = {
  standard: [0.4, 0.0, 0.2, 1],
  decelerate: [0.0, 0.0, 0.2, 1],
  accelerate: [0.4, 0.0, 1, 1],
  sharp: [0.4, 0.0, 0.6, 1],
  spring: { type: 'spring', stiffness: 300, damping: 30 },
  smooth: { type: 'spring', stiffness: 100, damping: 20 },
} as const;

// Common animation variants
export const fadeIn: Variants = {
  hidden: { opacity: 0 },
  visible: { 
    opacity: 1,
    transition: {
      duration: duration.normal,
      ease: ease.decelerate,
    },
  },
};

export const fadeInUp: Variants = {
  hidden: { opacity: 0, y: 20 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: {
      duration: duration.normal,
      ease: ease.decelerate,
    },
  },
};

export const fadeInScale: Variants = {
  hidden: { opacity: 0, scale: 0.95 },
  visible: { 
    opacity: 1, 
    scale: 1,
    transition: {
      duration: duration.normal,
      ease: ease.decelerate,
    },
  },
};

export const slideInRight: Variants = {
  hidden: { x: '100%', opacity: 0 },
  visible: { 
    x: 0, 
    opacity: 1,
    transition: {
      duration: duration.slow,
      ease: ease.decelerate,
    },
  },
  exit: { 
    x: '-100%', 
    opacity: 0,
    transition: {
      duration: duration.slow,
      ease: ease.accelerate,
    },
  },
};

export const scaleIn: Variants = {
  hidden: { scale: 0, opacity: 0 },
  visible: { 
    scale: 1, 
    opacity: 1,
    transition: {
      ...ease.spring,
      duration: duration.slow,
    },
  },
};

export const staggerContainer: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.05,
    },
  },
};

export const staggerItem: Variants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: duration.normal,
      ease: ease.decelerate,
    },
  },
};

// Shared element transition config
export const sharedTransition = {
  type: 'spring',
  stiffness: 200,
  damping: 25,
  mass: 0.5,
};

// Page transition variants
export const pageTransition: Variants = {
  initial: { opacity: 0, y: 20 },
  enter: { 
    opacity: 1, 
    y: 0,
    transition: {
      duration: duration.slow,
      ease: ease.decelerate,
    },
  },
  exit: { 
    opacity: 0, 
    y: -20,
    transition: {
      duration: duration.normal,
      ease: ease.accelerate,
    },
  },
};

// Gesture configs
export const tapScale = {
  scale: 0.97,
  transition: { duration: duration.fast },
};

export const hoverScale = {
  scale: 1.02,
  transition: { duration: duration.normal, ease: ease.decelerate },
};

// Helper to check reduced motion
export const prefersReducedMotion = () => {
  if (typeof window === 'undefined') return false;
  return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
};

// Wrapper for motion props with reduced motion support
export const getMotionProps = (variants: Variants) => {
  if (prefersReducedMotion()) {
    return {
      initial: false,
      animate: 'visible',
      variants: {
        visible: { opacity: 1 },
      },
    };
  }
  return {
    initial: 'hidden',
    animate: 'visible',
    variants,
  };
};
