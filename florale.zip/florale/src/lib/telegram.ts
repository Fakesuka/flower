'use client';

import { useEffect, useState } from 'react';
import type { TelegramTheme } from '@/types';

// Telegram Web Apps SDK types
interface TelegramWebApps {
  WebApp: {
    initData: string;
    initDataUnsafe: {
      user?: {
        id: number;
        first_name: string;
        last_name?: string;
        username?: string;
        language_code?: string;
        is_premium?: boolean;
      };
      query_id?: string;
      auth_date: number;
      hash: string;
    };
    version: string;
    platform: string;
    colorScheme: 'light' | 'dark';
    themeParams: TelegramTheme;
    isExpanded: boolean;
    viewportHeight: number;
    viewportStableHeight: number;
    headerColor: string;
    backgroundColor: string;
    BackButton: {
      isVisible: boolean;
      show: () => void;
      hide: () => void;
      onClick: (callback: () => void) => void;
      offClick: (callback: () => void) => void;
    };
    MainButton: {
      text: string;
      color: string;
      textColor: string;
      isVisible: boolean;
      isActive: boolean;
      isProgressVisible: boolean;
      setText: (text: string) => void;
      show: () => void;
      hide: () => void;
      enable: () => void;
      disable: () => void;
      showProgress: (leaveActive?: boolean) => void;
      hideProgress: () => void;
      onClick: (callback: () => void) => void;
      offClick: (callback: () => void) => void;
    };
    HapticFeedback: {
      impactOccurred: (style: 'light' | 'medium' | 'heavy' | 'rigid' | 'soft') => void;
      notificationOccurred: (type: 'error' | 'success' | 'warning') => void;
      selectionChanged: () => void;
    };
    expand: () => void;
    close: () => void;
    ready: () => void;
    setHeaderColor: (color: string) => void;
    setBackgroundColor: (color: string) => void;
    enableClosingConfirmation: () => void;
    disableClosingConfirmation: () => void;
  };
}

declare global {
  interface Window {
    Telegram?: TelegramWebApps;
  }
}

class TelegramBridge {
  private static instance: TelegramBridge;
  private webApp: TelegramWebApps['WebApp'] | null = null;

  private constructor() {
    if (typeof window !== 'undefined' && window.Telegram?.WebApp) {
      this.webApp = window.Telegram.WebApp;
      this.initialize();
    }
  }

  static getInstance(): TelegramBridge {
    if (!TelegramBridge.instance) {
      TelegramBridge.instance = new TelegramBridge();
    }
    return TelegramBridge.instance;
  }

  private initialize() {
    if (!this.webApp) return;

    // Expand to full height
    this.webApp.expand();
    
    // Signal ready
    this.webApp.ready();

    // Set theme colors
    this.applyTheme();

    // Disable vertical overscroll (iOS bounce)
    this.disableOverscroll();
  }

  private disableOverscroll() {
    if (typeof document !== 'undefined') {
      document.body.style.overscrollBehavior = 'none';
      document.documentElement.style.overscrollBehavior = 'none';
    }
  }

  private applyTheme() {
    if (!this.webApp) return;

    const theme = this.webApp.themeParams;
    const isDark = this.webApp.colorScheme === 'dark';

    // Set Telegram UI colors
    this.webApp.setHeaderColor(theme.headerBgColor || (isDark ? '#1c1c1e' : '#ffffff'));
    this.webApp.setBackgroundColor(theme.bgColor || (isDark ? '#000000' : '#ffffff'));

    // Apply CSS variables
    if (typeof document !== 'undefined') {
      const root = document.documentElement;
      root.style.setProperty('--tg-theme-bg-color', theme.bgColor || (isDark ? '#000000' : '#ffffff'));
      root.style.setProperty('--tg-theme-text-color', theme.textColor || (isDark ? '#ffffff' : '#000000'));
      root.style.setProperty('--tg-theme-hint-color', theme.hintColor || (isDark ? '#8e8e93' : '#8e8e93'));
      root.style.setProperty('--tg-theme-link-color', theme.linkColor || '#007aff');
      root.style.setProperty('--tg-theme-button-color', theme.buttonColor || '#007aff');
      root.style.setProperty('--tg-theme-button-text-color', theme.buttonTextColor || '#ffffff');
      root.style.setProperty('--tg-theme-secondary-bg-color', theme.secondaryBgColor || (isDark ? '#1c1c1e' : '#f2f2f7'));
      root.style.setProperty('--tg-theme-accent-text-color', theme.accentTextColor || '#007aff');
      root.setAttribute('data-theme', isDark ? 'dark' : 'light');
    }
  }

  // Getters
  get isAvailable(): boolean {
    return this.webApp !== null;
  }

  get user() {
    return this.webApp?.initDataUnsafe.user || null;
  }

  get userId(): number | null {
    return this.webApp?.initDataUnsafe.user?.id || null;
  }

  get colorScheme(): 'light' | 'dark' {
    return this.webApp?.colorScheme || 'light';
  }

  get themeParams(): TelegramTheme | null {
    return this.webApp?.themeParams || null;
  }

  get platform(): string {
    return this.webApp?.platform || 'unknown';
  }

  get safeAreaInset() {
    const vh = this.webApp?.viewportHeight || window.innerHeight;
    const stableVh = this.webApp?.viewportStableHeight || window.innerHeight;
    return {
      top: 0,
      bottom: Math.max(0, vh - stableVh),
    };
  }

  // Haptic Feedback
  haptic = {
    impact: (style: 'light' | 'medium' | 'heavy' | 'rigid' | 'soft' = 'medium') => {
      this.webApp?.HapticFeedback.impactOccurred(style);
    },
    notification: (type: 'error' | 'success' | 'warning') => {
      this.webApp?.HapticFeedback.notificationOccurred(type);
    },
    selection: () => {
      this.webApp?.HapticFeedback.selectionChanged();
    },
  };

  // Main Button
  mainButton = {
    show: (text: string, onClick: () => void) => {
      if (!this.webApp) return;
      this.webApp.MainButton.setText(text);
      this.webApp.MainButton.show();
      this.webApp.MainButton.enable();
      this.webApp.MainButton.onClick(onClick);
    },
    hide: () => {
      if (!this.webApp) return;
      this.webApp.MainButton.hide();
    },
    showProgress: () => {
      this.webApp?.MainButton.showProgress(false);
    },
    hideProgress: () => {
      this.webApp?.MainButton.hideProgress();
    },
    setText: (text: string) => {
      this.webApp?.MainButton.setText(text);
    },
    enable: () => {
      this.webApp?.MainButton.enable();
    },
    disable: () => {
      this.webApp?.MainButton.disable();
    },
  };

  // Back Button
  backButton = {
    show: (onClick: () => void) => {
      if (!this.webApp) return;
      this.webApp.BackButton.show();
      this.webApp.BackButton.onClick(onClick);
    },
    hide: () => {
      this.webApp?.BackButton.hide();
    },
  };

  // Utility
  close() {
    this.webApp?.close();
  }

  enableClosingConfirmation() {
    this.webApp?.enableClosingConfirmation();
  }

  disableClosingConfirmation() {
    this.webApp?.disableClosingConfirmation();
  }

  openLink(url: string) {
    if (this.webApp) {
      window.open(url, '_blank');
    }
  }

  openTelegramLink(url: string) {
    if (this.webApp) {
      window.open(url, '_blank');
    }
  }
}

// React Hook
export function useTelegram() {
  const [bridge] = useState(() => TelegramBridge.getInstance());
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    setIsReady(bridge.isAvailable);
  }, [bridge]);

  return {
    bridge,
    isReady,
    user: bridge.user,
    colorScheme: bridge.colorScheme,
    themeParams: bridge.themeParams,
    haptic: bridge.haptic,
    mainButton: bridge.mainButton,
    backButton: bridge.backButton,
  };
}

export default TelegramBridge.getInstance();
