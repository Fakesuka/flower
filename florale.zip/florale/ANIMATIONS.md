# Animation Examples

This file demonstrates key animation implementations in Florale.

## 1. GSAP Hero Scene (Home Page)

```tsx
// In src/app/page.tsx

useEffect(() => {
  if (!heroRef.current) return;

  const ctx = gsap.context(() => {
    // Title assembles from below
    gsap.from('.hero-title', {
      y: 100,
      opacity: 0,
      duration: 1.2,
      ease: 'power3.out',
    });

    // Subtitle follows
    gsap.from('.hero-subtitle', {
      y: 50,
      opacity: 0,
      duration: 1,
      delay: 0.3,
      ease: 'power3.out',
    });

    // Floating decorative elements
    gsap.to('.float-1', {
      y: -20,
      duration: 2,
      repeat: -1,
      yoyo: true,
      ease: 'sine.inOut',
    });
  }, heroRef);

  return () => ctx.revert(); // Cleanup
}, []);
```

## 2. Shared Element Transition (Product Card → Detail)

```tsx
// ProductCard.tsx
<motion.div
  layoutId={`product-image-${product.id}`}
  className="relative h-full w-full"
>
  <Image src={product.images[0]} alt={product.name} fill />
</motion.div>

// Product/[id]/page.tsx
<motion.div
  layoutId={`product-image-${product.id}`}
  transition={sharedTransition}
  className="relative h-full w-full"
>
  <Image src={product.images[selectedImage]} alt={product.name} fill />
</motion.div>

// Shared transition config (lib/motion.ts)
export const sharedTransition = {
  type: 'spring',
  stiffness: 200,
  damping: 25,
  mass: 0.5,
};
```

## 3. Story Swipe Gesture

```tsx
// StoryCarousel.tsx
const variants = {
  enter: (direction: number) => ({
    y: direction > 0 ? '100%' : '-100%',
    opacity: 0,
  }),
  center: {
    y: 0,
    opacity: 1,
  },
  exit: (direction: number) => ({
    y: direction > 0 ? '-100%' : '100%',
    opacity: 0,
  }),
};

<motion.div
  key={currentIndex}
  custom={direction}
  variants={variants}
  initial="enter"
  animate="center"
  exit="exit"
  drag="y"
  dragConstraints={{ top: 0, bottom: 0 }}
  dragElastic={0.2}
  onDragEnd={handleDragEnd}
>
  {/* Story content */}
</motion.div>
```

## 4. Timeline Progress Animation

```tsx
// Timeline.tsx

// Vertical progress line grows
<motion.div
  className="absolute left-6 top-0 w-0.5 bg-black"
  initial={{ height: 0 }}
  animate={{ height: `${(currentStatusIndex / (STATUSES.length - 1)) * 100}%` }}
  transition={{ duration: 1, ease: 'easeOut' }}
/>

// Active step pulses
{isCurrent && (
  <motion.div
    className="absolute inset-0 rounded-full bg-black"
    initial={{ opacity: 0.5, scale: 1 }}
    animate={{ opacity: 0, scale: 1.5 }}
    transition={{ repeat: Infinity, duration: 2 }}
  />
)}
```

## 5. Stagger Container (Product Grid)

```tsx
// Collections page
import { staggerContainer, staggerItem } from '@/lib/motion';

<motion.div
  variants={staggerContainer}
  initial="hidden"
  whileInView="visible"
  viewport={{ once: true }}
>
  {products.map((product) => (
    <motion.div key={product.id} variants={staggerItem}>
      <ProductCard product={product} />
    </motion.div>
  ))}
</motion.div>

// Motion config (lib/motion.ts)
export const staggerContainer: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.05,
    },
  },
};

export const staggerItem: Variants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.3,
      ease: [0.0, 0.0, 0.2, 1], // decelerate
    },
  },
};
```

## 6. Page Transitions

```tsx
// Layout wrapper for pages
import { AnimatePresence, motion } from 'framer-motion';
import { usePathname } from 'next/navigation';

export function PageTransition({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={pathname}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        transition={{ duration: 0.3 }}
      >
        {children}
      </motion.div>
    </AnimatePresence>
  );
}
```

## 7. Tap Feedback

```tsx
// Any interactive element
<motion.button
  whileTap={{ scale: 0.97 }}
  transition={{ duration: 0.15 }}
  onClick={() => {
    haptic.impact('medium'); // Telegram haptic
  }}
>
  Add to Cart
</motion.button>
```

## 8. Scroll-Triggered Animation (Optional GSAP + ScrollTrigger)

```tsx
// Advanced scroll-based reveals
gsap.from('.section', {
  scrollTrigger: {
    trigger: '.section',
    start: 'top 80%',
    end: 'top 20%',
    scrub: 1,
  },
  y: 100,
  opacity: 0,
});
```

## Performance Notes

1. **Use `transform` and `opacity` only** - Hardware accelerated
2. **Avoid `width`, `height`, `top`, `left`** - Triggers layout reflow
3. **Use `layoutId` sparingly** - Expensive on large lists
4. **Disable animations on low-end devices**:

```tsx
const shouldAnimate = !prefersReducedMotion();
```

5. **Use `will-change` carefully**:

```css
.animated-element {
  will-change: transform;
}
```

## Reduced Motion Support

Always respect user preferences:

```tsx
import { prefersReducedMotion } from '@/lib/motion';

const variants = prefersReducedMotion() 
  ? { visible: { opacity: 1 } } 
  : fadeInUp;
```

Or in CSS:

```css
@media (prefers-reduced-motion: reduce) {
  * {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}
```
