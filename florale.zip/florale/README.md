# 🌸 Florale — Premium Telegram Flower Shop

A production-ready, luxury Telegram Web App for an exclusive floral studio. Built with Next.js 14, TypeScript, Framer Motion, GSAP, and full Telegram integration.

## ✨ Features

### Core Experience
- **Interactive Bouquet Builder**: Step-by-step configurator with real-time price updates
- **Story-Style Collections**: Swipeable vertical stories showcasing curated collections
- **Product Scene Transitions**: Shared element animations between catalog and product pages
- **Order Tracking**: Animated timeline with delivery status updates
- **Premium Packaging Layer**: Visual packaging effects and customization

### Telegram Integration
- ✅ Full TWA SDK integration with haptic feedback
- ✅ Theme-aware (light/dark mode)
- ✅ MainButton & BackButton integration
- ✅ Safe area handling for iOS notches
- ✅ Prevents overscroll bounce
- ✅ Dynamic color theming from Telegram

### Animations & Performance
- **GSAP + ScrollTrigger**: Hero section with scroll-based animations
- **Framer Motion**: Page transitions, shared layouts, micro-interactions
- **Lenis**: Smooth scroll (optional, can be added)
- **Optimized Images**: Next.js Image component with lazy loading
- **60fps animations**: Hardware-accelerated transforms
- **Reduced motion support**: Respects user preferences

### State Management
- **Zustand**: Cart and builder state with persistence
- **Local Storage**: Auto-save builder progress
- **Type-safe**: Full TypeScript coverage

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ and npm/yarn/pnpm
- A Telegram account

### Installation

```bash
# Clone and install
cd florale
npm install

# Run development server
npm run dev
```

Visit `http://localhost:3000` to see the app.

## 📱 Testing in Telegram

To test as a real Telegram Web App:

### Option 1: Using ngrok (Recommended)

```bash
# Install ngrok
npm install -g ngrok

# In one terminal, run the dev server
npm run dev

# In another terminal, expose it
ngrok http 3000
```

You'll get a URL like `https://abc123.ngrok.io`

### Option 2: Using localtunnel

```bash
# Install localtunnel
npm install -g localtunnel

# Expose your local server
lt --port 3000
```

### Register Bot & Web App

1. **Create a bot**:
   - Message [@BotFather](https://t.me/BotFather) on Telegram
   - Send `/newbot` and follow prompts
   - Get your bot token

2. **Set Web App URL**:
   - Message BotFather with `/newapp`
   - Select your bot
   - Enter your ngrok/localtunnel URL
   - Upload app icon (optional)

3. **Launch**:
   - Open your bot in Telegram
   - Tap the Web App button
   - App launches with full Telegram integration!

### Testing Features

Once in Telegram, test:
- ✅ Haptic feedback on taps and selections
- ✅ MainButton shows "Add to Cart" on product pages
- ✅ BackButton navigation
- ✅ Theme switches with Telegram light/dark mode
- ✅ Safe area insets on iPhone notched devices

## 🏗️ Project Structure

```
florale/
├── src/
│   ├── app/                      # Next.js App Router pages
│   │   ├── page.tsx             # Home (hero + stories + featured)
│   │   ├── builder/             # Bouquet configurator
│   │   ├── collections/         # Browse all products
│   │   ├── product/[id]/        # Product detail with shared transition
│   │   ├── cart/                # Shopping cart
│   │   └── track/[orderId]/     # Order tracking timeline
│   ├── components/
│   │   ├── StoryCarousel.tsx    # Swipeable story cards
│   │   ├── ProductCard.tsx      # Product grid item
│   │   ├── BuilderStepper.tsx   # Multi-step configurator
│   │   └── Timeline.tsx         # Delivery tracking UI
│   ├── lib/
│   │   ├── telegram.ts          # Telegram Web Apps bridge
│   │   ├── motion.ts            # Animation variants & config
│   │   └── utils.ts             # Helpers (formatPrice, cn, etc.)
│   ├── store/
│   │   ├── cart.ts              # Cart state (Zustand)
│   │   └── builder.ts           # Builder state (Zustand)
│   ├── data/
│   │   ├── products.ts          # Mock product data
│   │   └── collections.ts       # Mock collections
│   ├── types/
│   │   └── index.ts             # TypeScript definitions
│   └── styles/
│       └── globals.css          # Global styles + Telegram theme vars
├── public/                       # Static assets
├── package.json
├── tailwind.config.ts
├── tsconfig.json
└── README.md
```

## 🎨 Design System

### Colors
- **Telegram Dynamic**: Uses `var(--tg-theme-*)` from Telegram
- **Custom Palette**: Black/white with stone/zinc grays
- **Accent**: Gold (#d4af37) for premium touches

### Typography
- **Headings**: Playfair Display (serif, elegant)
- **Body**: Geist Sans (modern, clean)

### Spacing
- Mobile-first: 360-430px optimized
- Safe area aware (iOS notches)
- Generous padding for touch targets

### Motion
- **Duration**: 150ms (fast) → 800ms (slower)
- **Easing**: Custom bezier curves for deceleration
- **Spring**: Physics-based for natural feel

## 🛠️ Tech Stack

| Layer | Technology |
|-------|------------|
| Framework | Next.js 14 (App Router) |
| Language | TypeScript |
| Styling | Tailwind CSS |
| Animations | Framer Motion + GSAP |
| State | Zustand |
| Forms | React Hook Form + Zod |
| Telegram | @telegram-apps/sdk |

## 📦 Key Components

### TelegramBridge (`lib/telegram.ts`)
Singleton class that:
- Initializes Telegram Web App SDK
- Provides haptic feedback methods
- Manages MainButton/BackButton
- Exposes theme params and user info
- React hook: `useTelegram()`

### BuilderStepper (`components/BuilderStepper.tsx`)
6-step configurator:
1. Choose style (classic, modern, minimal, wild, luxury)
2. Select color palette
3. Pick size (petite → statement)
4. Add packaging (craft, silk, luxury box)
5. Personal message (optional)
6. Review & confirm

Real-time price updates with `useBuilderStore()`.

### StoryCarousel (`components/StoryCarousel.tsx`)
Fullscreen vertical swipe cards:
- Drag gesture support
- Progress indicators
- Auto-advance option
- Links to collection detail

### Timeline (`components/Timeline.tsx`)
Animated delivery tracking:
- Vertical timeline with progress line
- Status: Preparing → Courier → On the way → Delivered
- Timestamps and courier info
- Pulse animation on active step

## 🎯 Performance

### Optimization Strategies
- Next.js Image: Automatic WebP, lazy load, blur placeholders
- Code splitting: Route-based with App Router
- State persistence: LocalStorage for cart/builder
- Reduced motion: Respects `prefers-reduced-motion`
- Hardware acceleration: `transform` and `opacity` only

### Lighthouse Targets
- Performance: 90+
- Accessibility: 95+
- Best Practices: 95+
- SEO: N/A (Telegram Web App)

## 🔒 Security & Privacy

- No sensitive data in localStorage
- Client-side only (no backend required for demo)
- Telegram `initData` validation (implement server-side for production)
- HTTPS required for Telegram Web Apps

## 🚢 Deployment

### Vercel (Recommended)

```bash
# Install Vercel CLI
npm install -g vercel

# Deploy
vercel
```

### Netlify

```bash
# Install Netlify CLI
npm install -g netlify-cli

# Build & deploy
npm run build
netlify deploy --prod
```

### Environment Variables

For production, set:
```env
NEXT_PUBLIC_BOT_TOKEN=your_bot_token_here
NEXT_PUBLIC_API_URL=your_api_url (if using backend)
```

## 🧪 Testing Checklist

- [ ] Home page hero animations
- [ ] Story carousel swipe gestures
- [ ] Product card → detail page transition
- [ ] Builder: all 6 steps with validation
- [ ] Cart: add/remove/update quantities
- [ ] Telegram MainButton integration
- [ ] Telegram BackButton navigation
- [ ] Haptic feedback on interactions
- [ ] Dark/light theme switching
- [ ] Safe area handling (iPhone)
- [ ] Reduced motion fallback

## 📚 Documentation

### Adding New Products

Edit `src/data/products.ts`:

```typescript
{
  id: 'p11',
  name: 'New Bouquet',
  subtitle: 'Seasonal Mix',
  description: '...',
  price: 9500,
  images: ['https://...'],
  category: 'modern',
  tags: ['new', 'seasonal'],
  inStock: true,
  featured: true,
}
```

### Custom Animations

Use motion variants from `lib/motion.ts`:

```tsx
import { fadeInUp } from '@/lib/motion';

<motion.div variants={fadeInUp}>
  Content
</motion.div>
```

### Telegram Haptics

```tsx
import { useTelegram } from '@/lib/telegram';

const { haptic } = useTelegram();

// Light tap
haptic.selection();

// Medium impact
haptic.impact('medium');

// Success notification
haptic.notification('success');
```

## 🤝 Contributing

This is a demo project. For production use:
1. Add real backend API integration
2. Implement payment processing
3. Add user authentication
4. Set up order management
5. Implement real-time delivery tracking
6. Add admin dashboard

## 📄 License

MIT

---

**Built with ❤️ for Telegram Web Apps**
