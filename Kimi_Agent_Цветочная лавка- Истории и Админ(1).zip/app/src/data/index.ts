import type { Product, Category, BuilderStyle, BuilderFlower, BuilderPalette, BuilderWrapping, Story } from '@/types';

export const categories: Category[] = [
  { id: 'bouquets', name: 'Букеты', icon: 'Flower2' },
  { id: 'potted', name: 'Горшечные растения', icon: 'Sprout' },
  { id: 'toys', name: 'Мягкие игрушки', icon: 'Heart' },
  { id: 'souvenirs', name: 'Сувениры', icon: 'Gift' },
  { id: 'balloons', name: 'Воздушные шары', icon: 'Circle' },
  { id: 'cards', name: 'Открытки', icon: 'Mail' },
  { id: 'garden', name: 'Садовые принадлежности', icon: 'Shovel' },
  { id: 'sweets', name: 'Сладости', icon: 'Candy' },
  { id: 'edible', name: 'Съедобные букеты', icon: 'Apple' },
  { id: 'compositions', name: 'Композиции', icon: 'LayoutGrid' },
];

// Stories data
export const stories: Story[] = [
  {
    id: '1',
    image: 'https://images.unsplash.com/photo-1561181286-d3fee7d55364?w=400&h=600&fit=crop',
    title: 'Новинки',
    isNew: true,
  },
  {
    id: '2',
    image: 'https://images.unsplash.com/photo-1519378058457-4c29a0a2efac?w=400&h=600&fit=crop',
    title: 'Скидки',
    isNew: false,
  },
  {
    id: '3',
    image: 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=400&h=600&fit=crop',
    title: 'Пионы',
    isNew: true,
  },
  {
    id: '4',
    image: 'https://images.unsplash.com/photo-1494972308805-463bc619d34e?w=400&h=600&fit=crop',
    title: 'Свадьба',
    isNew: false,
  },
  {
    id: '5',
    image: 'https://images.unsplash.com/photo-1468327768560-75b778cbb551?w=400&h=600&fit=crop',
    title: 'Лаванда',
    isNew: false,
  },
  {
    id: '6',
    image: 'https://images.unsplash.com/photo-1520763185298-1b434c919102?w=400&h=600&fit=crop',
    title: 'Тюльпаны',
    isNew: true,
  },
];

export const sizeOptions = [
  { id: 's', label: 'S', name: 'Мини', priceModifier: 0, description: 'Компактный букет' },
  { id: 'm', label: 'M', name: 'Классика', priceModifier: 1500, description: 'Стандартный размер' },
  { id: 'l', label: 'L', name: 'Премиум', priceModifier: 3500, description: 'Пышный букет' },
];

export const colorPalettes = [
  { id: 'gentle', name: 'Нежный', hex: '#F5E6E0' },
  { id: 'bright', name: 'Яркий', hex: '#E8B7BE' },
  { id: 'pastel', name: 'Пастель', hex: '#E6E6FA' },
  { id: 'mono', name: 'Моно', hex: '#FFFFFF' },
];

export const products: Product[] = [
  {
    id: '1',
    name: 'Пионовый рассвет',
    price: 4200,
    image: 'https://images.unsplash.com/photo-1561181286-d3fee7d55364?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1561181286-d3fee7d55364?w=600&h=600&fit=crop',
      'https://images.unsplash.com/photo-1562690868-60bbe7293e94?w=600&h=600&fit=crop',
      'https://images.unsplash.com/photo-1487530811176-3780de880c2d?w=600&h=600&fit=crop',
    ],
    category: 'bouquets',
    description: 'Нежные пионы, диантус и эвкалипт в воздушном оформлении. Идеальный выбор для романтического подарка.',
    composition: ['Пионы', 'Диантус', 'Эвкалипт', 'Гипсофила'],
    sizes: sizeOptions,
    colors: colorPalettes,
    isBestseller: true,
  },
  {
    id: '2',
    name: 'Розовая мечта',
    price: 3800,
    image: 'https://images.unsplash.com/photo-1519378058457-4c29a0a2efac?w=600&h=600&fit=crop',
    category: 'bouquets',
    description: 'Нежные розовые розы в элегантной упаковке. Классика, которая никогда не выходит из моды.',
    composition: ['Розы', 'Эвкалипт', 'Рускус'],
    sizes: sizeOptions,
    isNew: true,
  },
  {
    id: '3',
    name: 'Солнечная поляна',
    price: 2900,
    image: 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=600&h=600&fit=crop',
    category: 'bouquets',
    description: 'Яркие подсолнухи и ромашки создадут летнее настроение в любое время года.',
    composition: ['Подсолнухи', 'Ромашки', 'Зелень'],
    sizes: sizeOptions,
  },
  {
    id: '4',
    name: 'Белоснежная нежность',
    price: 5500,
    image: 'https://images.unsplash.com/photo-1494972308805-463bc619d34e?w=600&h=600&fit=crop',
    category: 'bouquets',
    description: 'Изящные белые лилии и розы для особенных моментов. Идеально для свадьбы.',
    composition: ['Лилии', 'Розы', 'Гипсофила', 'Эвкалипт'],
    sizes: sizeOptions,
  },
  {
    id: '5',
    name: 'Лавандовые поля',
    price: 3200,
    image: 'https://images.unsplash.com/photo-1468327768560-75b778cbb551?w=600&h=600&fit=crop',
    category: 'compositions',
    description: 'Ароматная лаванда с добавлением сухоцветов для долговечной красоты.',
    composition: ['Лаванда', 'Сухоцветы', 'Травы'],
    sizes: sizeOptions,
  },
  {
    id: '6',
    name: 'Тюльпановая весна',
    price: 2600,
    image: 'https://images.unsplash.com/photo-1520763185298-1b434c919102?w=600&h=600&fit=crop',
    category: 'bouquets',
    description: 'Свежие тюльпаны разных оттенков — вестники весны и радости.',
    composition: ['Тюльпаны', 'Зелень'],
    sizes: sizeOptions,
    isNew: true,
  },
  {
    id: '7',
    name: 'Орхидея Премиум',
    price: 6800,
    image: 'https://images.unsplash.com/photo-1566928401-4b1c5d7d8c3e?w=600&h=600&fit=crop',
    category: 'potted',
    description: 'Экзотическая орхидея в стильном кашпо. Премиальный подарок для ценителей.',
    composition: ['Орхидея фаленопсис', 'Мох', 'Декоративные камни'],
  },
  {
    id: '8',
    name: 'Садовая нежность',
    price: 3400,
    image: 'https://images.unsplash.com/photo-1508610048659-a06b669e3321?w=600&h=600&fit=crop',
    category: 'bouquets',
    description: 'Разноцветные герберы в пастельных тонах для ярких эмоций.',
    composition: ['Герберы', 'Хризантемы', 'Зелень'],
    sizes: sizeOptions,
  },
  {
    id: '9',
    name: 'Эвкалиптовый минимализм',
    price: 2100,
    image: 'https://images.unsplash.com/photo-1591886960571-74d43a9e4166?w=600&h=600&fit=crop',
    category: 'compositions',
    description: 'Монобукет из ароматного эвкалипта для любителей минимализма.',
    composition: ['Эвкалипт', 'Оливковые ветви'],
    sizes: sizeOptions,
  },
  {
    id: '10',
    name: 'Кустовые розы',
    price: 4500,
    image: 'https://images.unsplash.com/photo-1548097160-28b4e05760c6?w=600&h=600&fit=crop',
    category: 'bouquets',
    description: 'Пышные кустовые розы нежно-розового оттенка.',
    composition: ['Кустовые розы', 'Эвкалипт', 'Гипсофила'],
    sizes: sizeOptions,
    isBestseller: true,
  },
  {
    id: '11',
    name: 'Фикус Бенджамина',
    price: 3200,
    image: 'https://images.unsplash.com/photo-1599598425947-52006119087d?w=600&h=600&fit=crop',
    category: 'potted',
    description: 'Элегантное комнатное растение в керамическом горшке.',
    composition: ['Фикус Бенджамина', 'Керамический горшок'],
  },
  {
    id: '12',
    name: 'Плюшевый мишка',
    price: 1800,
    image: 'https://images.unsplash.com/photo-1556012018-50c5c0da73bf?w=600&h=600&fit=crop',
    category: 'toys',
    description: 'Мягкий плюшевый мишка 30 см. Прекрасное дополнение к букету.',
  },
  {
    id: '13',
    name: 'Воздушные шары "Сердца"',
    price: 1200,
    image: 'https://images.unsplash.com/photo-1530103862676-de3c9a59aa38?w=600&h=600&fit=crop',
    category: 'balloons',
    description: 'Набор из 5 фольгированных шаров в форме сердца.',
  },
  {
    id: '14',
    name: 'Открытка ручной работы',
    price: 350,
    image: 'https://images.unsplash.com/photo-1586075010923-2dd4570fb338?w=600&h=600&fit=crop',
    category: 'cards',
    description: 'Уникальная открытка ручной работы с конвертом.',
  },
  {
    id: '15',
    name: 'Съедобный букет "Фруктовый"',
    price: 2800,
    image: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?w=600&h=600&fit=crop',
    category: 'edible',
    description: 'Букет из свежих фруктов — вкусный и красивый подарок.',
    composition: ['Яблоки', 'Груши', 'Виноград', 'Цитрусовые'],
  },
  {
    id: '16',
    name: 'Коробка конфет Raffaello',
    price: 890,
    image: 'https://images.unsplash.com/photo-1549007994-cb92caebd54b?w=600&h=600&fit=crop',
    category: 'sweets',
    description: 'Классические конфеты Raffaello в подарочной упаковке.',
  },
];

// Builder Data
export const builderStyles: BuilderStyle[] = [
  {
    id: 'gentle',
    name: 'Нежный',
    description: 'Воздушные композиции в пастельных тонах',
    image: 'https://images.unsplash.com/photo-1561181286-d3fee7d55364?w=400&h=500&fit=crop',
  },
  {
    id: 'bold',
    name: 'Смелый',
    description: 'Яркие контрастные сочетания',
    image: 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=400&h=500&fit=crop',
  },
  {
    id: 'minimal',
    name: 'Минималистичный',
    description: 'Лаконичные монобукеты',
    image: 'https://images.unsplash.com/photo-1591886960571-74d43a9e4166?w=400&h=500&fit=crop',
  },
  {
    id: 'garden',
    name: 'Садовый',
    description: 'Естественные полевые композиции',
    image: 'https://images.unsplash.com/photo-1508610048659-a06b669e3321?w=400&h=500&fit=crop',
  },
];

export const builderFlowers: BuilderFlower[] = [
  { id: 'peony', name: 'Пионы', image: 'https://images.unsplash.com/photo-1561181286-d3fee7d55364?w=200&h=200&fit=crop', price: 800 },
  { id: 'rose', name: 'Розы', image: 'https://images.unsplash.com/photo-1519378058457-4c29a0a2efac?w=200&h=200&fit=crop', price: 400 },
  { id: 'tulip', name: 'Тюльпаны', image: 'https://images.unsplash.com/photo-1520763185298-1b434c919102?w=200&h=200&fit=crop', price: 200 },
  { id: 'lily', name: 'Лилии', image: 'https://images.unsplash.com/photo-1494972308805-463bc619d34e?w=200&h=200&fit=crop', price: 600 },
  { id: 'sunflower', name: 'Подсолнухи', image: 'https://images.unsplash.com/photo-1470509037663-253afd7f0f51?w=200&h=200&fit=crop', price: 350 },
  { id: 'lavender', name: 'Лаванда', image: 'https://images.unsplash.com/photo-1468327768560-75b778cbb551?w=200&h=200&fit=crop', price: 450 },
  { id: 'eucalyptus', name: 'Эвкалипт', image: 'https://images.unsplash.com/photo-1591886960571-74d43a9e4166?w=200&h=200&fit=crop', price: 300 },
  { id: 'orchid', name: 'Орхидеи', image: 'https://images.unsplash.com/photo-1566928401-4b1c5d7d8c3e?w=200&h=200&fit=crop', price: 1200 },
];

export const builderPalettes: BuilderPalette[] = [
  { id: 'white', name: 'Белая', colors: ['#FFFFFF', '#F5F5F5', '#FAFAFA'] },
  { id: 'pink', name: 'Розовая', colors: ['#FFE4E1', '#FFB6C1', '#FFC0CB'] },
  { id: 'red', name: 'Красная', colors: ['#FFE4E1', '#DC143C', '#B22222'] },
  { id: 'yellow', name: 'Желтая', colors: ['#FFFACD', '#FFD700', '#FFA500'] },
  { id: 'purple', name: 'Фиолетовая', colors: ['#E6E6FA', '#DDA0DD', '#9370DB'] },
  { id: 'mixed', name: 'Микс', colors: ['#FFE4E1', '#FFFACD', '#E6E6FA'] },
];

export const builderWrappings: BuilderWrapping[] = [
  { id: 'kraft', name: 'Крафт', image: 'https://images.unsplash.com/photo-1582794543139-8ac92a900275?w=200&h=200&fit=crop', price: 200 },
  { id: 'powder', name: 'Пудра', image: 'https://images.unsplash.com/photo-1519378058457-4c29a0a2efac?w=200&h=200&fit=crop', price: 300 },
  { id: 'silk', name: 'Шёлк', image: 'https://images.unsplash.com/photo-1494972308805-463bc619d34e?w=200&h=200&fit=crop', price: 500 },
  { id: 'none', name: 'Без упаковки', image: 'https://images.unsplash.com/photo-1591886960571-74d43a9e4166?w=200&h=200&fit=crop', price: 0 },
];

export const messagePresets = [
  { id: 'love', text: 'С любовью ❤️' },
  { id: 'warmth', text: 'Счастья и тепла ☀️' },
  { id: 'thanks', text: 'Спасибо за всё 🌸' },
  { id: 'birthday', text: 'С Днём Рождения! 🎉' },
  { id: 'custom', text: 'Свой текст' },
];
